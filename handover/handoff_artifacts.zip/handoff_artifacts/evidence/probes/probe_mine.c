/* Independent reproduction of I-01 and I-05 (not the teammate's probes).
   Barcode '*Z*' at the course scale: narrow 3 ms, wide 9 ms (about
   0.33 m/s for 3 mm / 9 mm bars). */
#include <stdio.h>
#include <string.h>
#include "app_config.h"
#include "subsystem3/bc_capture.h"
#include "navigation/nav_sm.h"

static uint32_t g_t[30];
static void make_edges(void)
{
    static char const *chars[3] = { "nwnnwnwnn", "nwwnwnnnn", "nwnnwnwnn" }; /* * Z * */
    uint32_t t = 1000000u, k = 0u;
    for (int c = 0; c < 3; c++) {
        for (int e = 0; e < 9; e++) { g_t[k++] = t; t += (chars[c][e] == 'w') ? 9000u : 3000u; }
        if (c < 2) { g_t[k++] = t; t += 3000u; }
    }
    g_t[29] = t;                                   /* end of the last bar */
}
static char const *name(bc_out_t o)
{ return o.type == BC_OUT_LETTER ? "LETTER" : o.type == BC_OUT_FAILED ? "FAILED" : o.type == BC_OUT_STARTED ? "STARTED" : "NONE"; }
static bc_out_t drain(bc_capture_t *c, uint32_t now)
{
    bc_out_t r = { BC_OUT_NONE, { 0, false, 0 } };
    for (int i = 0; i < 4; i++) { bc_out_t o = bc_capture_poll(c, now); if (o.type == BC_OUT_NONE) break; if (o.type != BC_OUT_STARTED) r = o; }
    return r;
}
static void i01(void)
{
    static bc_capture_t c;
    bc_out_t o;
    make_edges();
    /* control: clean symbol */
    bc_capture_init(&c, false, 0u);
    for (int k = 0; k < 30; k++) bc_capture_edge(&c, g_t[k], (k % 2) == 0);
    o = drain(&c, g_t[29] + 5000u);
    printf("I-01 control, clean *Z*: %s '%c'\n", name(o), o.result.letter ? o.result.letter : '-');
    /* 20 edges in one 5 ms batch already polled, then a batch with a lost
       space edge at edge 25 (bar 24 and bar 26 merge) is impossible to
       decode; instead lose the edge pair-wise: drop edge 27 only, so the
       level stays dark at edge 28 (non-alternating) and edge 29 completes
       the count in the same batch. */
    bc_capture_init(&c, false, 0u);
    for (int k = 0; k < 27; k++) bc_capture_edge(&c, g_t[k], (k % 2) == 0);
    (void) drain(&c, g_t[26] + 100u);             /* previous 5 ms poll */
    bc_capture_edge(&c, g_t[28], true);           /* edge 27 (white) lost: dark again */
    bc_capture_edge(&c, g_t[28] + 1500u, false);  /* chatter inside the last bar */
    bc_capture_edge(&c, g_t[28] + 1500u + 1100u, true);
    bc_capture_edge(&c, g_t[29], false);
    o = drain(&c, g_t[29] + 5000u);
    printf("I-01 lost edge inside the symbol, completed in the same batch: %s '%c' reason %u\n",
           name(o), o.result.letter ? o.result.letter : '-', o.result.reason);
}

static nav_sm_t g;
static line_err_t gl;
static uint32_t now;
static void tick(uint32_t health, bool start)
{ now += 5u; nav_sm_clear_actions(&g); nav_sm_tick(&g, now, &gl, health, false, start); }
static void lev(uint8_t type, char letter)
{ line_evt_t e; memset(&e, 0, sizeof e); e.type = type; e.letter = letter; nav_sm_clear_actions(&g); g.now_ms = now; nav_sm_line_event(&g, &e); }
static void done(void)
{ motion_sts_t s; memset(&s, 0, sizeof s); s.type = MOTION_STS_MOVE_DONE; s.move_id = g.pending_move_id; nav_sm_clear_actions(&g); g.now_ms = now; nav_sm_motion_status(&g, &s); }
static void i05(void)
{
    memset(&gl, 0, sizeof gl); gl.b_valid = 1u; gl.b_line_seen = 1u;
    now = 0u; nav_sm_init(&g, now);
    for (int i = 0; i < 4; i++) tick(NAV_HEALTH_ALL, false);
    tick(NAV_HEALTH_ALL, true);
    /* hold an A (straight) first, so the junction is passed straight */
    lev(LINE_EVT_CAPTURE_STARTED, 0); lev(LINE_EVT_LETTER, 'A');
    lev(LINE_EVT_CAPTURE_STARTED, 0);              /* a second read starts */
    lev(LINE_EVT_JUNCTION, 0);                     /* junction reached mid-read */
    done(); done();                                /* axle on junction, straight */
    for (int i = 0; i < 3 && g.mode != NAV_MODE_LINE_FOLLOWING; i++) { tick(NAV_HEALTH_ALL, false); if (g.pending_move_id) done(); }
    lev(LINE_EVT_LETTER, 'C');                     /* the old read's letter, late */
    printf("I-05 junction mid-read: mode %d (following=%d), command held %d letter '%c' (stale C held = defect)\n",
           (int) g.mode, (int) NAV_MODE_LINE_FOLLOWING, (int) g.b_command_held, g.b_command_held ? g.held_letter : '-');
}
int main(void) { i01(); i05(); return 0; }
