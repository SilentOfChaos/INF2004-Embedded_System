/* probe_nav_i05.c - each I-05 scenario on its own: is the stale read's
   letter held?  Build against an old or a new nav_sm.c. */
#include <stdio.h>
#include <string.h>
#include "app_config.h"
#include "navigation/nav_sm.h"

static nav_sm_t sm;
static line_err_t line;
static uint32_t now;

static void tick_full(uint32_t h, bool f, bool s) { now += CFG_PERIOD_NAV_MS; nav_sm_clear_actions(&sm); nav_sm_tick(&sm, now, &line, h, f, s); }
static void tick(void) { tick_full(NAV_HEALTH_ALL, false, false); }
static void ev(uint8_t t, char l) { line_evt_t e = { 0 }; e.type = t; e.letter = l; nav_sm_clear_actions(&sm); sm.now_ms = now; nav_sm_line_event(&sm, &e); }
static void done(void) { motion_sts_t s = { 0 }; s.type = MOTION_STS_MOVE_DONE; s.move_id = sm.pending_move_id; nav_sm_clear_actions(&sm); sm.now_ms = now; nav_sm_motion_status(&sm, &s); }
static void boot(bool start) { memset(&sm, 0, sizeof(sm)); now = 0; nav_sm_init(&sm, now); memset(&line, 0, sizeof(line)); line.b_valid = 1; line.b_line_seen = 1; tick(); tick(); if (start) tick_full(NAV_HEALTH_ALL, false, true); }

int main(void)
{
    /* 1 line lost during a read */
    boot(true); ev(LINE_EVT_CAPTURE_STARTED, 0); ev(LINE_EVT_LOST, 0); tick(); ev(LINE_EVT_LETTER, 'B');
    printf("line-lost read: stale letter held=%d (mode %d)\n", sm.b_command_held, sm.mode);
    /* 2 junction during a read */
    boot(true); ev(LINE_EVT_CAPTURE_STARTED, 0); ev(LINE_EVT_LETTER, 'B'); ev(LINE_EVT_CAPTURE_STARTED, 0); ev(LINE_EVT_JUNCTION, 0); done(); done(); tick(); ev(LINE_EVT_LETTER, 'C');
    printf("junction read: stale letter held=%d (mode %d)\n", sm.b_command_held, sm.mode);
    /* 3 fault during a read, then a new run */
    boot(true); ev(LINE_EVT_CAPTURE_STARTED, 0); tick_full(NAV_HEALTH_ALL, true, false); nav_sm_clear_actions(&sm); nav_sm_restart(&sm); tick(); tick_full(NAV_HEALTH_ALL, false, true); ev(LINE_EVT_LETTER, 'B');
    printf("fault + new run: stale letter held=%d (mode %d)\n", sm.b_command_held, sm.mode);
    /* 4 read started in READY */
    boot(false); ev(LINE_EVT_CAPTURE_STARTED, 0); tick_full(NAV_HEALTH_ALL, false, true); ev(LINE_EVT_LETTER, 'B');
    printf("started in READY: stale letter held=%d (mode %d)\n", sm.b_command_held, sm.mode);
    /* 5 hump during a read: should count */
    boot(true); ev(LINE_EVT_CAPTURE_STARTED, 0); { imu_evt_t h = { 0 }; h.type = IMU_EVT_HUMP_START; nav_sm_clear_actions(&sm); nav_sm_imu_event(&sm, &h); } ev(LINE_EVT_LETTER, 'B');
    printf("hump during a read: letter held=%d (mode %d)\n", sm.b_command_held, sm.mode);
    return 0;
}
