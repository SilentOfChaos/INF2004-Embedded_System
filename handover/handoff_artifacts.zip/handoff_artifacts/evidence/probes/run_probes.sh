#!/usr/bin/env bash
# run_probes.sh <probe-dir> <label>|<tree-dir>...
# Builds probe_claims.c and probe_nav_i05.c against each tree's app_program/
# (the same C files testing/host/Makefile compiles) and prints what each
# probe reports.
set -eu
P=$(cd "$1" && pwd); shift
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
for arg in "$@"; do
  label=${arg%%|*}; tree=$(cd "${arg#*|}" && pwd)
  app="$tree/app_program"
  srcs=()
  for f in common/fixmath.c subsystem1/cmd_parse.c subsystem1/tlm_json.c \
           subsystem1/tlm_format.c subsystem2/motion_ctl.c subsystem3/bc_decode.c \
           subsystem3/bc_capture.c subsystem3/line_track.c subsystem3/steering.c \
           subsystem3/letter_map.c subsystem4/imu_calc.c subsystem5/scan_logic.c \
           navigation/nav_sm.c; do
    srcs+=("$app/$f")
  done
  echo "===== $label"
  for probe in probe_claims probe_nav_i05; do
    gcc -std=c99 -O1 -I"$app" -o "$OUT/$probe" "$P/$probe.c" "${srcs[@]}" -lm
    [ "$probe" = probe_nav_i05 ] && echo "-- I-05 transitions"
    "$OUT/$probe"
  done
  echo
done
