/*
 * probe_claims.c - reproduce the reviewer's I-01, I-02 and I-03 claims
 * against a given source tree (built with -I<tree>/app_program).
 * Not part of the repository.
 */
#include <stdio.h>
#include <string.h>

#include "app_config.h"
#include "subsystem3/bc_capture.h"
#include "subsystem5/scan_logic.h"
#include "navigation/nav_sm.h"

#define N 10000u
#define W 30000u

static char const g_star[] = "nwnnwnwnn";
static char const g_a[]    = "wnnnnwnnw";

static void symbol(uint32_t *w)
{
    char const *chars[3] = { g_star, g_a, g_star };
    uint32_t pos = 0;
    for (int c = 0; c < 3; c++) {
        for (int e = 0; e < 9; e++) { w[pos++] = (chars[c][e] == 'w') ? W : N; }
        if (c < 2) { w[pos++] = N; }
    }
}

/* feed edges [from, to) of the symbol; returns the time of edge `to-1` */
static uint32_t feed(bc_capture_t *cap, uint32_t const *w, uint32_t from, uint32_t to)
{
    uint32_t t = 500000u;
    uint32_t last = t;
    for (uint32_t e = 0; e < to; e++) {
        if (e >= from) { bc_capture_edge(cap, t, (e % 2u) == 0u); last = t; }
        if (e < 29u) { t += w[e]; }
    }
    return last;
}

static char const *otype(bc_out_t o)
{
    switch (o.type) {
    case BC_OUT_NONE: return "NONE";
    case BC_OUT_STARTED: return "STARTED";
    case BC_OUT_LETTER: return "LETTER";
    default: return "FAILED";
    }
}

static bc_out_t poll_all(bc_capture_t *cap, uint32_t now)
{
    bc_out_t last = { BC_OUT_NONE, { 0, false, 0 } };
    for (int i = 0; i < 4; i++) {
        bc_out_t o = bc_capture_poll(cap, now);
        if (o.type == BC_OUT_NONE) break;
        if (o.type != BC_OUT_STARTED) last = o;
    }
    return last;
}

static void i01(void)
{
    static bc_capture_t cap;
    uint32_t w[29];
    uint32_t last;
    bc_out_t o;

    symbol(w);
    printf("I-01 (barcode capture)\n");

    /* (a) reviewer's sequence: all 30 edges stored, then a loss mark */
    bc_capture_init(&cap, false, 0u);
    last = feed(&cap, w, 0u, 30u);
    bc_capture_mark_lost(&cap);
    o = poll_all(&cap, last + 2000u);
    printf("  a) 30 edges stored, then mark_lost, poll: %s '%c' reason %u\n",
           otype(o), o.result.letter ? o.result.letter : '-', o.result.reason);

    /* (b) Line woken by the overflow flag while edge 29 (the 30th) is
       still queued: mark at 29 stored edges, then the drain, then poll */
    bc_capture_init(&cap, false, 0u);
    (void) feed(&cap, w, 0u, 29u);
    bc_capture_mark_lost(&cap);                 /* OVF wake, before drain */
    last = feed(&cap, w, 29u, 30u);             /* tick: drain */
    o = poll_all(&cap, last + 2000u);           /* tick: poll */
    printf("  b) mark_lost at 29 stored edges, drain 30th, poll: %s '%c' reason %u\n",
           otype(o), o.result.letter ? o.result.letter : '-', o.result.reason);

    /* (c) level mismatch inside the symbol, then the 30th edge in the
       same batch */
    bc_capture_init(&cap, false, 0u);
    last = feed(&cap, w, 0u, 29u);
    bc_capture_edge(&cap, last + 4000u, true);  /* dark again: lost white */
    last = feed(&cap, w, 29u, 30u);
    o = poll_all(&cap, last + 2000u);
    printf("  c) same-level edge at 29 stored edges, 30th in same batch, poll: %s '%c' reason %u\n",
           otype(o), o.result.letter ? o.result.letter : '-', o.result.reason);
}

static void i02(void)
{
    static nav_sm_t sm;
    line_err_t line;
    uint32_t now = 0u;

    printf("I-02 (stale line record)\n");
    memset(&line, 0, sizeof(line));
    line.b_valid = 1u; line.b_line_seen = 1u; line.error_pm = 0; line.time_ms = 0u; line.seq = 1u;
    nav_sm_init(&sm, now);
    for (int i = 0; i < 3; i++) { now += 5u; nav_sm_clear_actions(&sm); nav_sm_tick(&sm, now, &line, NAV_HEALTH_ALL, false, false); }
    now += 5u; nav_sm_clear_actions(&sm); nav_sm_tick(&sm, now, &line, NAV_HEALTH_ALL, false, true);
    printf("  mode after START: %d (LINE_FOLLOWING=%d)\n", (int) sm.mode, (int) NAV_MODE_LINE_FOLLOWING);
    now = 10000u;
    nav_sm_clear_actions(&sm);
    nav_sm_tick(&sm, now, &line, 0u /* no health bits */, false, false);
    for (uint32_t i = 0; i < sm.act_count; i++) {
        if (sm.acts[i].type == (uint8_t) NAV_ACT_DRIVE) {
            printf("  record time 0 ms, tick at %u ms, health 0: DRIVE %d mm/s (mode %d)\n",
                   (unsigned) now, (int) sm.acts[i].a_value, (int) sm.mode);
        }
    }
}

static void i03(void)
{
    scan_set_t set;
    scan_profile_t p;
    int32_t lo = 0, hi = 0;

    printf("I-03 (scan coverage)\n");
    scan_set_clear(&set);
    scan_set_add(&set, 60, 0, false);
    scan_set_add(&set, 90, 300, true);
    scan_set_add(&set, 120, 0, false);
    scan_profile(&set, &p);
    printf("  60 invalid, 90 = 300 mm, 120 invalid: found %d clear L %d R %d side %u (LEFT=%u)\n",
           p.b_found, (int) p.clear_left_mm, (int) p.clear_right_mm, p.side, (unsigned) OBST_SIDE_LEFT);

    scan_set_clear(&set);
    scan_set_add(&set, 30, 4000, true);
    scan_set_add(&set, 60, 4000, true);
    scan_set_add(&set, 90, 0, false);
    scan_set_add(&set, 120, 4000, true);
    scan_set_add(&set, 150, 4000, true);
    printf("  coarse: centre invalid, others far: hit found %d (no hit => PATH_CLEAR in scan_coarse_done)\n",
           scan_hit_range(&set, &lo, &hi));
}

int main(void)
{
    i01();
    i02();
    i03();
    return 0;
}
