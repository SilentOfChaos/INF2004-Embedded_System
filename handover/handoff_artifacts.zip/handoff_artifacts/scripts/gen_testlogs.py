import sys, os
root = sys.argv[1]

LEGEND = """*Method:* **host** = host unit test, built and run with `make` in
`testing/host/` (no hardware; see `testing/README.md`);
**auto** = `TEST_CHECK` in the on-target test image (`make TEST=1`), result
printed on the console; **manual** = a person observes or measures the
result (scope, logic analyser, ruler, broker client, phone app ...)."""

RESULTS = """## Results

Add a new row for every run. Never edit or delete old rows. No test has
been run on the car yet.

| Date | Test ID | Commit | Tester | Result | Log / evidence | Notes |
|---|---|---|---|---|---|---|
| YYYY-MM-DD | {first} | `abc1234` | | PASS / FAIL | `logs/YYYY-MM-DD_….txt` | |
"""

def table(rows):
    out = ["| ID | What is tested | Requirement / interface | Method | Steps / how | Expected result |",
           "|---|---|---|---|---|---|"]
    for r in rows:
        out.append("| " + " | ".join(r) + " |")
    return "\n".join(out)

def write(path, title, header, intro, rows):
    text = "# " + title + "\n\n" + header + "\n\n"
    text += "See `testing/README.md` for how to run tests and record results.\n"
    if intro:
        text += "\n" + intro + "\n"
    text += "\n## Test cases\n\nDefine a test here before running it. Test IDs never change.\n\n"
    text += table(rows) + "\n\n" + LEGEND + "\n\n"
    text += RESULTS.format(first=rows[0][0])
    with open(os.path.join(root, path), "w") as f:
        f.write(text)

def host(id_, what, req, exp=None):
    src = {"S1": "test_s1.c", "S2": "test_s2.c", "S3": "test_s3.c", "S4": "test_s4.c",
           "S5": "test_s5.c", "NA": "test_nav.c", "CO": "test_common.c"}[id_[:2]]
    return [id_, what, req, "host", "`testing/host/" + src + "`", exp or ("`[TEST] %s PASS`" % id_)]

def auto(id_, what, req, src):
    return [id_, what, req, "auto", "`" + src + "`", "`[TEST] %s PASS`" % id_]

# ---------------------------------------------------------------- S1
s1 = [
 host("S1-U01", "each command form parses with its fields", "FR6, FR14, NFR14, D-66"),
 host("S1-U02", "bad commands are rejected; `seq` kept for the ack", "FR14, D-66"),
 host("S1-U03", "JSON field readers stay inside their buffers", "NFR15"),
 host("S1-U04", "IPv4 address check for the broker command", "NFR14"),
 host("S1-U05", "JSON writer: exact output; overflow gives 0, never a cut message", "D-49"),
 host("S1-U06", "route log: totals, indexes, full log, new run clears it", "FR13"),
 host("S1-U07", "run summary: time, distance, how the run ended", "FR14, FR18"),
 host("S1-U08", "every message, with every field at its extreme, fits `CFG_MQTT_PAYLOAD_MAX`", "D-49"),
 host("S1-U09", "route entries carry the fields of their kind", "FR13"),
 host("S1-U10", "unknown codes print as \"?\", never read out of range", "NFR15"),
 auto("S1-U20", "Telemetry drains its input queue", "IF-12", "subsystem1_test.c"),
 auto("S1-U21", "publish, command and broker queues and the flag exist", "IF-13, IF-14, IF-15", "subsystem1_test.c"),
 auto("S1-U22", "nothing is queued for MQTT while the session is down", "NFR10", "subsystem1_test.c"),
 ["S1-U30", "telemetry and heartbeat rates on the broker", "NFR9", "manual",
  "1. Build `NET=lwip MQTT=1`, flash. 2. `mosquitto_sub -v -t 'inf2004/IS19/#'` with time stamps for 60 s. 3. Count telemetry and status messages.",
  "270–330 telemetry, 54–66 status messages; `seq` without gaps"],
 ["S1-U31", "remap acknowledged within 1 s and used at the next barcode", "FR6, NFR8, IF-10", "manual",
  "1. Publish `{\"seq\":1,\"cmd\":\"remap\",\"letter\":\"E\",\"action\":\"left\"}` on `inf2004/IS19/cmd`. 2. Time the ack. 3. Pass barcode E.",
  "ack `ok` 1 within 1 s; route event `act` \"left\""],
 ["S1-U32", "summary command: summary event, then the route log replayed", "FR13, FR14", "manual",
  "1. Run part of the course. 2. Publish `{\"seq\":2,\"cmd\":\"summary\"}`.",
  "ack, one summary event, then every logged entry with `re` 1"],
 ["S1-U33", "broker command moves the car to a second broker; reset goes back", "NFR14, D-16", "manual",
  "1. Start a second broker. 2. Publish the broker command. 3. Watch both brokers. 4. Reset the Pico.",
  "ack on the old broker, telemetry on the new one within a few s; after reset on the old one again"],
 ["S1-U34", "broker unreachable: the car keeps running; retries back off", "NFR10, report 6.1, D-70", "manual",
  "1. Stop the broker during a run. 2. Watch the console for 2 min. 3. Start it again.",
  "mode unchanged; retries after 1, 2, 4 … 30 s; telemetry resumes"],
]
write("subsystem1/TEST_LOG.md", "Subsystem 1 — test log",
      "**Subsystem:** Wi-Fi / MQTT commands and telemetry  ·  **Owner:** Ang Hung Ling  ·  **Code:** `app_program/subsystem1/`",
      None, s1)

# ---------------------------------------------------------------- S2
s2 = [
 host("S2-U01", "encoder counts ↔ mm (uses the UNVALIDATED geometry)", "FR19"),
 host("S2-U02", "pivot-turn counts", "FR19, D-56"),
 host("S2-U03", "wheel speed and odometry heading, with signs", "FR12, NFR18"),
 host("S2-U04", "PID: feed-forward, duty limit, anti-windup, zero target brakes", "NFR3, NFR18"),
 host("S2-U05", "soft start; slowing down at once; stop before reversing", "D-30"),
 auto("S2-U20", "command queue exists and Motion drains it", "IF-07", "subsystem2_test.c"),
 auto("S2-U21", "Motion's event flag exists (cyclic release, reset)", "IF-09", "subsystem2_test.c"),
 ["S2-U30", "encoder counts per wheel turn, in the chosen decoding mode", "A2, D-28", "manual",
  "Turn each wheel 10 times by hand; read the counts on the console.", "value recorded; `CFG_ENC_COUNTS_PER_REV` updated"],
 ["S2-U31", "wheel diameter, track width, sensor-to-axle distance, car width", "A2", "manual",
  "Measure on the car.", "values recorded; `app_config.h` updated"],
 ["S2-U32", "motor and encoder directions", "", "manual",
  "Command a slow forward drive with the wheels off the ground.", "both wheels forward; both counts increase (else set the `INVERT` settings)"],
 ["S2-U33", "speed loop period", "NFR3", "manual", "Toggle a spare pin each Motion cycle; logic analyser for 10 s.", "20 ± 2 ms"],
 ["S2-U34", "straight driving", "NFR18", "manual", "Drive 1 m straight at 250 mm/s, 5 times.", "each wheel within ±10% of target; drift ≤ 2 cm per metre"],
 ["S2-U35", "commanded distance", "FR19", "manual", "`moveForward(500)` 5 times; measure.", "500 mm ± 5%"],
 ["S2-U36", "commanded turns", "FR19", "manual", "`turnLeft`/`turnRight` 45° and 90°, 5 times each; measure.", "within ±5°"],
]
write("subsystem2/TEST_LOG.md", "Subsystem 2 — test log",
      "**Subsystem:** motion (motors, encoders, PID)  ·  **Owner:** Dominic Ng Jun Jie  ·  **Code:** `app_program/subsystem2/`",
      None, s2)

# ---------------------------------------------------------------- S3
s3 = [
 host("S3-U01", "all 26 letters forwards (design note UT-B3-01)", "FR2"),
 host("S3-U02", "all 26 letters backwards: same letter, marked reversed; Z, K, O never read as T, U, X (UT-B3-02, UT-B3-03)", "FR2"),
 host("S3-U03", "speed change of ±25% across one barcode (UT-B3-04)", "FR2"),
 host("S3-U04", "comparator bias: bars +40%, spaces −40% and the opposite (UT-B3-05)", "FR2, D-27"),
 host("S3-U05", "no letter from wrong counts, non-letters, flat widths, wide gaps, wrong ends (UT-B3-06, UT-B3-07)", "FR2"),
 host("S3-U06", "capture: letter just after the 30th edge, not 120 ms later", "D-26"),
 host("S3-U07", "capture: glitches under 1 ms removed, also on the first bar", "D-25"),
 host("S3-U08", "capture starts only after 120 ms of white", "D-25"),
 host("S3-U09", "capture: crossbar, too few, extra and lost edges give no letter (UT-B3-06, UT-B3-08)", "FR2, D-26"),
 host("S3-U10", "capture: edge and time limits always end it", "D-26"),
 host("S3-U11", "line error sign and limits (UT-B3-09)", "FR1, IF-02"),
 host("S3-U12", "one junction per crossbar; line lost after exactly 300 ms; found again", "FR3, FR18"),
 host("S3-U13", "level adaptation follows slowly, stays within its limits, frozen when off", "D-23"),
 host("S3-U14", "steering: sign, gains, limit, slow-down", "FR1"),
 host("S3-U15", "letter map: defaults, remap, bad input", "FR6"),
 auto("S3-U20", "line-error record updated about every 5 ms", "NFR1, IF-02", "subsystem3_test.c"),
 auto("S3-U21", "both ADC readings in the plausible range", "D-24", "subsystem3_test.c"),
 auto("S3-U22", "line error stays within −1000..1000", "IF-02", "subsystem3_test.c"),
 ["S3-U30", "black and white ADC levels of both sensors", "A3, D-63", "manual",
  "Read the raw values on the console over the line and over the floor, at both lighting levels.", "levels recorded; `CFG_LINE_*` updated"],
 ["S3-U31", "barcode sensor D0 level over a bar", "A3", "manual", "Read GP7 with a bar under the sensor.", "`CFG_BC_DARK_LEVEL` confirmed or changed"],
 ["S3-U32", "30 edges per pass of the sample barcode at 3 speeds", "A3, NFR2", "manual",
  "Log GP7 on a logic analyser while pushing the car over the barcode at 0.15, 0.25, 0.35 m/s.", "30 edges per pass; no extra edges after the glitch filter"],
 ["S3-U33", "Line period and CPU load with the 1 ms tick", "NFR1, NFR13, A12", "manual",
  "Claim GP6, set `CFG_PIN_TIMING_PROBE` 6; logic analyser for 10 s, with and without the Wi-Fi build.", "5 ± 1 ms"],
 ["S3-U34", "barcode edge timing under encoder interrupt load", "A8, NFR2", "manual",
  "Feed a known square wave into GP7 while both wheels run at full speed.", "width error under 1% of a narrow bar at 0.35 m/s"],
]
write("subsystem3/TEST_LOG.md", "Subsystem 3 — test log",
      "**Subsystem:** line following, junctions, barcodes  ·  **Owner:** Nga Wei Yang  ·  **Code:** `app_program/subsystem3/`",
      "Design-note test IDs (`UT-B3-xx`, docs/notes/05 section 11) are given next to the matching S3 tests.", s3)

# ---------------------------------------------------------------- S4
s4 = [
 host("S4-U01", "roll and pitch from gravity", "FR8"),
 host("S4-U02", "tilt-compensated heading on rotated test vectors (36 headings × 9 tilts)", "FR4, D-40"),
 host("S4-U03", "vector length; hump height from the table", "FR8"),
 host("S4-U04", "hump: on after 100 ms above, off when level, peak kept", "FR8"),
 host("S4-U05", "motion classes: still, steady, accelerating, turning, climbing, descending, impact", "FR17, D-58"),
 auto("S4-U20", "no fault latched after start-up on a still car", "FR15", "subsystem4_test.c"),
 auto("S4-U21", "IMU identified, calibrated and healthy", "D-57", "subsystem4_test.c"),
 auto("S4-U22", "fault queue exists and Safety drains it", "IF-04", "subsystem4_test.c"),
 ["S4-U30", "IMU axes on the car", "", "manual",
  "Lift the left side: roll on the console must rise; turn the car left: heading must rise.", "signs correct (else set `CFG_IMU_SWAP`/`INVERT`)"],
 ["S4-U31", "magnetometer hard-iron offsets", "FR4", "manual",
  "Turn the car through 360° on the floor; record min and max of each axis.", "offsets recorded; `CFG_IMU_MAG_OFF_*` updated"],
 ["S4-U32", "hump height table", "FR8, A4", "manual",
  "Drive one wheel over blocks of known height (10, 20, 30, 40 mm), 3 times each.", "reported height within ±5 mm; table updated"],
 ["S4-U33", "motor drive removed after a collision or STOP", "NFR6, FR15", "manual",
  "Scope GP8 and a pin toggled at the fault; trigger by STOP command and by tapping the car.", "pins low within 50 ms"],
 ["S4-U34", "watchdog resets the Pico when a critical task stops checking in", "report section 3, D-44", "manual",
  "On a test branch only, remove the Line task's check-in.", "reset within about 250 ms"],
 ["S4-U35", "RESET releases only when the cause is cleared and Motion acknowledged", "NFR16", "manual",
  "Latch a fault; press RESET while the car is still being shaken, then when still.", "no release while shaking; release after, motors stay at 0"],
 ["S4-U36", "IMU sample rates", "NFR4", "manual", "Count samples on the console for 10 s.", "accelerometer 100 ± 5 Hz, magnetometer 75 ± 5 Hz"],
]
write("subsystem4/TEST_LOG.md", "Subsystem 4 — test log",
      "**Subsystem:** IMU and safety  ·  **Owner:** Yee Sheng Chua  ·  **Code:** `app_program/subsystem4/`",
      None, s4)

# ---------------------------------------------------------------- S5
s5 = [
 host("S5-U01", "echo width to range; invalid and out-of-range echoes", "D-61"),
 host("S5-U02", "coarse hits give the fine-scan angles", "FR10"),
 host("S5-U03", "profile of an obstacle ahead: distance, edges, width, clearances", "FR10, D-62"),
 host("S5-U04", "side with room for the car, or none", "FR11, D-62"),
 auto("S5-U20", "ultrasonic sensor gives valid readings", "A5, D-57", "subsystem5_test.c"),
 auto("S5-U21", "request queue exists and Scan drains it", "IF-06", "subsystem5_test.c"),
 ["S5-U30", "servo positions", "", "manual", "Command 0°, 90°, 180°; check with a protractor.", "within ±5° (else adjust `CFG_SERVO_US_AT_*`)"],
 ["S5-U31", "range accuracy", "A5, FR9", "manual", "Flat target at 10, 20, 30, 50, 100 cm, 10 readings each.", "within ±1 cm"],
 ["S5-U32", "ping spacing", "NFR5", "manual", "Logic analyser on GP4 for 10 s.", "pings at least 60 ms apart"],
 ["S5-U33", "obstacle profile accuracy", "FR10", "manual", "Box of known size at known positions; read the plan event.", "position, width, closest point, clearances within ±2 cm"],
]
write("subsystem5/TEST_LOG.md", "Subsystem 5 — test log",
      "**Subsystem:** ultrasonic scanning and obstacle profile  ·  **Owner:** Wong Qian Hui  ·  **Code:** `app_program/subsystem5/`",
      None, s5)

# ---------------------------------------------------------------- NAV
nav = [
 host("NAV-U01", "BOOT → SELF-TEST → READY → LINE FOLLOWING on START only", "FR16"),
 host("NAV-U02", "SELF-TEST failure reported once after 3 s", "report 5, D-39"),
 host("NAV-U03", "steers towards the line; keeps the last error when the line is briefly gone", "FR1, D-52"),
 host("NAV-U04", "SD1: letter B held, junction, axle onto it, turn left 90°, find the line", "FR3, FR4"),
 host("NAV-U05", "right, U-turn and straight at a junction", "FR4, D-34"),
 host("NAV-U06", "junction with no command: SAFE HOLD and \"no command\" logged; RESET → READY", "FR5, D-54"),
 host("NAV-U07", "line lost: sweep search for 5 s, then COMPLETE with a summary", "FR18, D-33"),
 host("NAV-U08", "line found during the search: following again", "FR18"),
 host("NAV-U09", "no line within 3 s of a turn: SAFE HOLD", "report 5"),
 host("NAV-U10", "barcode and junction events ignored while turning", "D-53"),
 host("NAV-U11", "a newer letter replaces the held one; a failed read keeps it", "D-35"),
 host("NAV-U12", "remap and default map, each acknowledged", "FR6, NFR8"),
 host("NAV-U13", "fault from a running mode; restart goes back through SELF-TEST", "FR15, D-64"),
 host("NAV-U14", "hump: slower, levels frozen, height logged", "FR7, FR8"),
 host("NAV-U15", "obstacle: stop, scan, go round on the left, rejoin the line", "FR9, FR11, D-36"),
 host("NAV-U16", "no room: reverse 10 cm once, scan again, then SAFE HOLD; path clear: carry on", "FR11"),
 host("NAV-U17", "a running move is kept alive every tick", "report 6.2, D-55"),
 host("NAV-U18", "fused heading starts from odometry and is nudged by the compass", "D-40"),
 host("NAV-U19", "the action list never overflows in one step", "NFR15"),
 auto("NAV-U20", "every event queue exists and Navigation drains it", "IF-01, 03, 05, 08, 10", "navigation_test.c"),
 auto("NAV-U21", "Navigation's event flag exists", "IF-16, IF-17", "navigation_test.c"),
 ["NAV-U30", "one START press starts one run", "FR16, D-65", "manual", "Press START briefly, then hold it for 2 s.", "one run each time; nothing while held"],
]
write("navigation/TEST_LOG.md", "Navigation (shared) — test log",
      "**Part:** Navigation, the system statechart  ·  **Owner:** whole team  ·  **Code:** `app_program/navigation/`",
      None, nav)

# ---------------------------------------------------------------- COMMON
com = [
 host("COM-U01", "clamp, absolute value and angle wrapping", "D-13"),
 host("COM-U02", "atan2 within 0.03° over the full circle, any input size", "D-13"),
 host("COM-U03", "sine and cosine within 3/32768", "D-13"),
 host("COM-U04", "Q15 multiply and division round to nearest", "D-13"),
 host("COM-U05", "integer square root rounds down", "D-13"),
 host("COM-U06", "table interpolation and its ends", "D-13"),
]
write("common/TEST_LOG.md", "Common code — test log",
      "**Part:** shared helpers  ·  **Owner:** whole team  ·  **Code:** `app_program/common/`",
      None, com)
