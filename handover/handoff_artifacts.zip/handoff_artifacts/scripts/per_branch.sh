#!/bin/bash
SP=/tmp/claude-0/-home-user-INF2004-IS19/5b9ec659-e66f-563e-800c-986e0ee067a2/scratchpad
export PICO_SDK_PATH=/opt/pico/pico-sdk
OUT=$SP/rv/ev/per_branch.txt; : > $OUT
for b in shared s1 s2 s3 s4 s5; do
  D=$SP/rv/pb_$b; rm -rf $D; mkdir -p $D
  git -C /home/user/INF2004_IS19 archive rv/$b | tar -x -C $D
  cp $D/config/wifi_secrets.example.h $D/config/wifi_secrets.h
  (cd $D/testing/host && make clean >/dev/null 2>&1; make > $SP/rv/ev/pb_host_$b.log 2>&1; echo "rv/$b $(git -C /home/user/INF2004_IS19 rev-parse --short rv/$b) host rc=$? $(grep -h SUMMARY $SP/rv/ev/pb_host_$b.log)" >> $OUT)
  (cd $D/build_make && make -j8 > $SP/rv/ev/pb_build_$b.log 2>&1; echo "rv/$b default build rc=$? warnings=$(grep -ci warning $SP/rv/ev/pb_build_$b.log)" >> $OUT; make -j8 NET=lwip MQTT=1 > $SP/rv/ev/pb_build_mqtt_$b.log 2>&1; echo "rv/$b mqtt build rc=$? warnings=$(grep -ci warning $SP/rv/ev/pb_build_mqtt_$b.log)" >> $OUT)
  rm -f $D/config/wifi_secrets.h
done
echo DONE >> $OUT
