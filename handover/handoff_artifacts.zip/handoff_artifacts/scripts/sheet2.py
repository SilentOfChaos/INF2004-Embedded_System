import sys, os
from PIL import Image, ImageDraw
out, cols, cell = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
files = sys.argv[4:]
rows = (len(files) + cols - 1) // cols
sheet = Image.new('RGB', (cols * cell, rows * (cell + 24)), 'white')
d = ImageDraw.Draw(sheet)
for k, f in enumerate(files):
    im = Image.open(f).convert('RGB'); im.thumbnail((cell, cell))
    x = (k % cols) * cell; y = (k // cols) * (cell + 24)
    sheet.paste(im, (x, y + 24)); d.text((x + 4, y + 4), os.path.basename(f)[:40], fill='black')
sheet.save(out); print(sheet.size)
