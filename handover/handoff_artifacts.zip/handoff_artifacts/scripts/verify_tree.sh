#!/bin/bash
# usage: verify_tree.sh <git-ref> <outdir>   (builds 7 profiles + host tests on a clean export)
REF="$1"; OUT="$2"; SP=/tmp/claude-0/-home-user-INF2004-IS19/5b9ec659-e66f-563e-800c-986e0ee067a2/scratchpad
export PICO_SDK_PATH=/opt/pico/pico-sdk
D="$SP/rv/build_$(echo $REF | tr '/' '_')"; rm -rf "$D" "$OUT"; mkdir -p "$D" "$OUT"
git -C /home/user/INF2004_IS19 archive "$REF" | tar -x -C "$D"
cp "$D/config/wifi_secrets.example.h" "$D/config/wifi_secrets.h"
cd "$D/build_make"
for p in "" "TEST=1" "NET=lwip MQTT=1" "NET=lwip MQTT=1 TEST=1" "SMP=0" "CONSOLE=uart WIFI=none" "CRASH_REPORT=1"; do
  tag=$(echo "${p:-default}" | tr ' =' '__')
  make -j8 $p > "$OUT/build_$tag.log" 2>&1; rc=$?
  elf=$(ls -t *.elf | head -1)
  echo "[$p] rc=$rc warnings=$(grep -ci 'warning' "$OUT/build_$tag.log") $(arm-none-eabi-size "$elf" | tail -1 | awk '{print "text="$1" data="$2" bss="$3}')" >> "$OUT/build_summary.txt"
done
for c in cc_cmd cc_cmd_mqtt_test; do "$SP/scripts/warncheck.sh" "$D" "$SP/$c.txt" > "$OUT/warncheck_$c.log" 2>&1; echo "warncheck $c rc=$?" >> "$OUT/build_summary.txt"; done
cd "$D/testing/host"
for cc in gcc clang; do for san in 0 1; do make clean >/dev/null 2>&1; make CC=$cc SAN=$san > "$OUT/host_${cc}_san$san.log" 2>&1; echo "host $cc SAN=$san rc=$? $(grep -h 'SUMMARY' "$OUT/host_${cc}_san$san.log")" >> "$OUT/host_summary.txt"; done; done
rm -f "$D/config/wifi_secrets.h"
