#!/bin/bash
# Re-compile every app_program C file with extra warnings, using the
# exact flags the template makefile used for app_main.c.
# usage: warncheck.sh <repo> <cc_cmd.txt> [extra flags...]
REPO="$1"; CMDFILE="$2"; shift 2
EXTRA="$*"
BASE=$(sed -e 's/-MF"[^"]*"//' -e 's/-MT"[^"]*"//' -e 's/-c -o "[^"]*" "[^"]*"//' "$CMDFILE")
cd "$REPO/build_make" || exit 1
rc=0
for f in $(cd .. && find app_program -name '*.c' | sort); do
  out=$(eval "$BASE -Wall -Wextra -Wshadow -Wno-unused-parameter $EXTRA -c -o /dev/null ../$f" 2>&1)
  if [ -n "$out" ]; then echo "=== $f"; echo "$out" | grep -E "warning|error" | head -20; rc=1; fi
done
exit $rc
