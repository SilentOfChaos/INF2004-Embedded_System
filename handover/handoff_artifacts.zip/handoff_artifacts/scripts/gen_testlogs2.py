import sys, os
root = sys.argv[1]
exec(open(os.path.join(os.path.dirname(sys.argv[0]), "gen_common.py")).read()) if False else None

LEGEND = """*Method:* **auto** = `TEST_CHECK` in the on-target test image (`make TEST=1`),
result printed on the console; **manual** = a person observes or measures
the result (scope, logic analyser, ruler, broker client, phone app ...)."""

RESULTS = """## Results

Add a new row for every run. Never edit or delete old rows. No test has
been run on the car yet.

| Date | Test ID | Commit | Tester | Result | Log / evidence | Notes |
|---|---|---|---|---|---|---|
| YYYY-MM-DD | {first} | `abc1234` | | PASS / FAIL | `logs/YYYY-MM-DD_….txt` | |
"""

def table(rows):
    out = ["| ID | What is tested | Requirement / interface | Method | Steps / how | Expected result |",
           "|---|---|---|---|---|---|"]
    for r in rows:
        out.append("| " + " | ".join(r) + " |")
    return "\n".join(out)

def write(path, title, intro, rows):
    text = "# " + title + "\n\n" + intro + "\n\n"
    text += "See `testing/README.md` for how to run tests and record results.\n"
    text += "\n## Test cases\n\nDefine a test here before running it. Test IDs never change.\n\n"
    text += table(rows) + "\n\n" + LEGEND + "\n\n"
    text += RESULTS.format(first=rows[0][0])
    with open(os.path.join(root, path), "w") as f:
        f.write(text)

m = "manual"
integ = [
 ["INT-01", "Line events reach Navigation: barcode letter held, junction acted on", "IF-01", m,
  "Push the car by hand over barcode B and a crossbar in a test run; watch the console and the route log.", "letter B logged, then AT JUNCTION and a left turn"],
 ["INT-02", "line-error record read by Navigation every cycle", "IF-02", m,
  "Move the car across the line by hand while READY; watch the 5 Hz telemetry `line` field.", "error changes sign from side to side; never stale for more than 10 ms"],
 ["INT-03", "IMU events reach Navigation: hump start/end, heading", "IF-03", m,
  "Tilt the car past the hump threshold and back while following.", "HUMP CROSSING, then a hump route entry"],
 ["INT-04", "faults from IMU, Command and a full queue latch Safety", "IF-04", m,
  "Tap the car; publish STOP; (test branch) fill a control queue.", "FAULT latched with the right cause and source each time"],
 ["INT-05", "obstacle events reach Navigation", "IF-05", m, "Put a box 25 cm ahead while following.", "AVOIDING, plan event logged"],
 ["INT-06", "scan requests reach Obstacle Scan", "IF-06", m, "Same run as INT-05; watch the servo.", "coarse then fine scan after the car stops"],
 ["INT-07", "Motion carries out Navigation's commands", "IF-07", m, "Run NAV junction sequence with the wheels off the ground.", "forward, turn, stop as commanded"],
 ["INT-08", "odometry and move-done reach Navigation", "IF-08", m, "Same run as INT-07.", "each move finishes the right step; distance in telemetry"],
 ["INT-09", "RESET handshake: Motion zeroes before Safety releases", "IF-09, NFR16", m,
  "Latch a fault while driving; press RESET.", "zero ack, then release; motors stay still until START"],
 ["INT-10", "remap command reaches Navigation and is acknowledged", "IF-10, NFR8", m, "As S1-U31.", "ack within 1 s"],
 ["INT-11", "level adaptation frozen on a hump; RUN OVER after COMPLETE", "IF-11", m,
  "Cross a hump; then let the line run out.", "levels unchanged on the hump; Line idle after COMPLETE"],
 ["INT-12", "status records from every task reach Telemetry", "IF-12", m, "Watch the 5 Hz telemetry for 30 s.", "line, motion, IMU, scan, mode and safety fields all change"],
 ["INT-13", "Telemetry messages reach the broker", "IF-13", m, "As S1-U30.", "all four topics seen"],
 ["INT-14", "commands from the broker reach the Command task", "IF-14", m, "Publish each command once.", "one ack per command"],
 ["INT-15", "broker change reaches the MQTT code", "IF-15, NFR14", m, "As S1-U33.", "car moves to the new broker"],
 ["INT-16", "FAULT level stops Motion and Navigation; restart after release", "IF-16, FR15", m,
  "Latch a fault while driving; then RESET.", "Motion BRAKED, Navigation FAULT; then SELF-TEST, READY"],
 ["INT-17", "health levels let SELF-TEST pass; a missing sensor fails it", "IF-17, D-57", m,
  "Boot normally; then boot with the ultrasonic sensor unplugged.", "READY; then FAULT (self-test) after 3 s"],
 ["INT-18", "watchdog check-ins from every critical task", "IF-18, D-44", m, "As S4-U34, once for each task.", "reset each time"],
]
write("integration/TEST_LOG.md", "Integration — test log",
      "Tests that two or more subsystems work together: one or more for every interface in TEAM.md section 5. Both owners agree on the test and sign off the result.",
      integ)

sysrows = [
 ["SYS-01", "full course, start to finish, no operator input", "FR1, NFR7", m, "Run the course 3 times.", "finished each time in under 5 min"],
 ["SYS-02", "sample barcodes in both directions at 3 speeds", "FR2", m,
  "20 passes each at 0.15, 0.25, 0.35 m/s, both orientations (design-note ST-B3-01).", "no wrong letter; failed reads logged"],
 ["SYS-03", "command acted on at the next junction, final heading", "FR3, FR4", m, "Barcodes A–D before junctions, 5 times each.", "right action at the junction; heading within ±5°"],
 ["SYS-04", "junction with no command", "FR5", m, "Junction with no barcode before it.", "car stops; \"no_command\" event"],
 ["SYS-05", "remap over MQTT without reflashing", "FR6, NFR8", m, "Remap E to right; run over barcode E.", "turns right at the junction"],
 ["SYS-06", "hump crossing and height", "FR7, FR8", m, "Run over each hump 3 times.", "stays on the line; count right; height within ±5 mm"],
 ["SYS-07", "obstacle: stop, profile, bypass, rejoin", "FR9, FR10, FR11", m,
  "Obstacle on the line, room on one side; then no room on either side.", "stops ≥ 10 cm before; passes 5–10 cm away; rejoins. No room: reverses 10 cm once, then stops"],
 ["SYS-08", "telemetry content and rates", "FR12, NFR9", m, "As S1-U30 during a run.", "all FR12 fields present; 5 Hz and 1 Hz"],
 ["SYS-09", "route log and run summary on request", "FR13, FR14", m, "Summary command after a run.", "every barcode, turn, hump and obstacle with distance and time"],
 ["SYS-10", "collision and STOP: brake, latch, alarm until RESET", "FR15, NFR6, NFR16", m, "As S4-U33 and S4-U35 on the course.", "drive removed within 50 ms; latched until RESET"],
 ["SYS-11", "still after power-on until START", "FR16", m, "Power on and wait 60 s; then press START.", "no movement before START"],
 ["SYS-12", "motion classes and turn rate reported", "FR17", m, "Run the course; watch the event topic.", "each class seen where expected"],
 ["SYS-13", "line loss: search, stop, summary", "FR18", m, "Lift the car off the line while following.", "search for 5 ± 0.5 s, then stop and publish the summary"],
 ["SYS-14", "Wi-Fi or broker loss during a run", "NFR10", m, "Switch the broker off mid-run.", "car carries on in the same mode"],
 ["SYS-15", "power bank", "NFR12", m, "Full course 3 times on the 5 V / 2.1 A bank.", "no reset"],
 ["SYS-16", "CPU load", "NFR13", m, "Timing probes on each task (S3-U33 method); add up busy time.", "≤ 60%"],
 ["SYS-17", "line following range", "NFR17", m, "0.15 and 0.35 m/s, at 200 and 1000 lux, across tile joins.", "stays on the line"],
 ["SYS-18", "RAM", "NFR19", m, "Map file (TEAM.md section 6) plus a run-time check of free memory.", "below 75% of 264 KB"],
 ["SYS-19", "no more than 3.3 V on any GPIO", "NFR11", m, "Inspect the wiring; meter each sensor output.", "≤ 3.3 V"],
 ["SYS-20", "broker address changed without reflashing", "NFR14", m, "As S1-U33.", "car on the new broker"],
]
write("system/TEST_LOG.md", "System — test log",
      "Tests of the complete car against its requirements (docs/notes/04 section 1), run on the final hardware set-up. Run the full set before every demo and before hand-in.",
      sysrows)
