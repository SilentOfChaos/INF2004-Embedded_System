import sys, glob
from PIL import Image
C39 = {
 '0':'nnnwwnwnn','1':'wnnwnnnnw','2':'nnwwnnnnw','3':'wnwwnnnnn','4':'nnnwwnnnw',
 '5':'wnnwwnnnn','6':'nnwwwnnnn','7':'nnnwnnwnw','8':'wnnwnnwnn','9':'nnwwnnwnn',
 'A':'wnnnnwnnw','B':'nnwnnwnnw','C':'wnwnnwnnn','D':'nnnnwwnnw','E':'wnnnwwnnn',
 'F':'nnwnwwnnn','G':'nnnnnwwnw','H':'wnnnnwwnn','I':'nnwnnwwnn','J':'nnnnwwwnn',
 'K':'wnnnnnnww','L':'nnwnnnnww','M':'wnwnnnnwn','N':'nnnnwnnww','O':'wnnnwnnwn',
 'P':'nnwnwnnwn','Q':'nnnnnnwww','R':'wnnnnnwwn','S':'nnwnnnwwn','T':'nnnnwnwwn',
 'U':'wwnnnnnnw','V':'nwwnnnnnw','W':'wwwnnnnnn','X':'nwnnwnnnw','Y':'wwnnwnnnn',
 'Z':'nwwnwnnnn','-':'nwnnnnwnw','.':'wwnnnnwnn',' ':'nwwnnnwnn','*':'nwnnwnwnn',
 '$':'nwnwnwnnn','/':'nwnwnnnwn','+':'nwnnnwnwn','%':'nnnwnwnwn'}
INV = {v:k for k,v in C39.items()}
def runs(img, y):
    px = img.load(); w = img.size[0]
    out = []; cur = None; n = 0
    for x in range(w):
        b = px[x, y] < 128
        if b == cur: n += 1
        else:
            if cur is not None: out.append((cur, n))
            cur, n = b, 1
    out.append((cur, n))
    # strip leading/trailing white
    while out and not out[0][0]: out.pop(0)
    while out and not out[-1][0]: out.pop()
    return out
def decode(widths):
    nar = min(widths); thr = 2.0 * nar
    s = ''.join('w' if w > thr else 'n' for w in widths)
    chars = []
    i = 0
    while i + 9 <= len(s):
        chars.append(INV.get(s[i:i+9], '?')); i += 10  # skip inter-char gap
    return s, ''.join(chars)
for f in sorted(glob.glob(sys.argv[1] + '*.png')):
    im = Image.open(f).convert('L'); y = im.size[1] // 3
    r = runs(im, y); widths = [n for _, n in r]
    nar = min(widths)
    s, fwd = decode(widths); _, rev = decode(widths[::-1])
    dpi = 300.0
    print(f.split('/')[-1], 'elements', len(widths), 'narrow px', nar, 'wide px', max(widths),
          'ratio %.2f' % (max(widths)/nar), 'total mm %.1f' % (sum(widths)/dpi*25.4),
          'narrow mm %.2f' % (nar/dpi*25.4), 'fwd', fwd, 'rev', rev)
