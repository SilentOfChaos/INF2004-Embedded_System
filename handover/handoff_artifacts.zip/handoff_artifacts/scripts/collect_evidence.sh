#!/bin/bash
# Fresh build and host-test evidence for the handover, on a clean
# worktree of origin/main.  usage: collect_evidence.sh <scratch>
S="$1"; OUT="$S/evidence"; WT="$S/ev_wt"; REPO=/home/user/INF2004_IS19
export PICO_SDK_PATH=/opt/pico/pico-sdk
rm -rf "$OUT"; mkdir -p "$OUT"
git -C "$REPO" worktree remove --force "$WT" > /dev/null 2>&1
git -C "$REPO" fetch -q origin main
git -C "$REPO" worktree add -f --detach "$WT" origin/main > /dev/null 2>&1 || { echo "worktree failed"; exit 1; }
{
  echo "date_utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "commit: $(git -C "$WT" rev-parse HEAD)"
  echo "tree:   $(git -C "$WT" rev-parse HEAD^{tree})"
  echo "--- arm-none-eabi-gcc"; arm-none-eabi-gcc --version | head -1
  echo "--- host cc"; cc --version | head -1
  echo "--- clang"; clang --version 2>/dev/null | head -1 || echo "clang not found"
  echo "--- make"; make --version | head -1
  echo "--- pico-sdk"; grep -E "set\(PICO_SDK_VERSION_(MAJOR|MINOR|REVISION)" "$PICO_SDK_PATH/pico_sdk_version.cmake"
  echo "--- uname"; uname -srm
} > "$OUT/env.txt" 2>&1
# Placeholder secrets so the Wi-Fi builds compile; deleted at the end.
cp "$WT/config/wifi_secrets.example.h" "$WT/config/wifi_secrets.h"
cd "$WT/build_make"
: > "$OUT/build_summary.txt"
for p in "" "TEST=1" "NET=lwip MQTT=1" "NET=lwip MQTT=1 TEST=1" "SMP=0" "WIFI=none"; do
  tag=$(echo "${p:-default}" | tr ' =' '__')
  make -j8 $p > "$OUT/build_$tag.log" 2>&1; rc=$?
  warn=$(grep -ci 'warning' "$OUT/build_$tag.log")
  err=$(grep -cE "error:|\*\*\*" "$OUT/build_$tag.log")
  elf=$(ls -t *.elf | head -1)
  uf2="${elf%.elf}.uf2"
  {
    echo "== profile [${p:-default}] rc=$rc warnings=$warn errors=$err image=$elf"
    arm-none-eabi-size "$elf"
    echo "uf2_bytes: $(stat -c %s "$uf2" 2>/dev/null)"
    arm-none-eabi-nm "$elf" | grep -E " (end|__bss_end__|__StackTop|__HeapLimit)$"
  } >> "$OUT/build_summary.txt"
  if [ -n "$p" ] && [ "$p" = "NET=lwip MQTT=1" ]; then :; fi
done
# Extra-warning recompile of every app_program file (exact template flags
# plus -Wall -Wextra -Wshadow), default, MQTT and MQTT+TEST flag sets.
for c in cc_cmd cc_cmd_mqtt cc_cmd_mqtt_test; do
  "$S/scripts/warncheck.sh" "$WT" "$S/$c.txt" > "$OUT/warncheck_$c.log" 2>&1
  echo "warncheck $c rc=$?" >> "$OUT/build_summary.txt"
done
# Host unit tests: default compiler, clang, and gcc with ASan+UBSan.
cd "$WT/testing/host"
make clean > /dev/null 2>&1; make > "$OUT/host_cc.log" 2>&1; echo "host cc rc=$?" > "$OUT/host_summary.txt"
make clean > /dev/null 2>&1; make CC=clang > "$OUT/host_clang.log" 2>&1; echo "host clang rc=$?" >> "$OUT/host_summary.txt"
make clean > /dev/null 2>&1; make CC=gcc SAN=1 > "$OUT/host_gcc_san.log" 2>&1; echo "host gcc SAN=1 rc=$?" >> "$OUT/host_summary.txt"
make clean > /dev/null 2>&1
grep -hE "SUMMARY|passed|failed" "$OUT"/host_*.log | sort | uniq -c >> "$OUT/host_summary.txt"
rm -f "$WT/config/wifi_secrets.h"
cd "$REPO" && git worktree remove --force "$WT"
git -C "$REPO" worktree prune
echo DONE >> "$OUT/host_summary.txt"
