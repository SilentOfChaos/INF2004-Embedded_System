#!/bin/bash
# usage: verify_branch.sh <branch> <worktree-dir> <scratch> [mqtt]
BR="$1"; WT="$2"; S="$3"; MQ="$4"
export PICO_SDK_PATH=/opt/pico/pico-sdk
git -C /home/user/INF2004_IS19 worktree add -f "$WT" "$BR" > /dev/null 2>&1 || { echo "worktree failed"; exit 1; }
cp /home/user/INF2004_IS19/config/wifi_secrets.example.h "$WT/config/wifi_secrets.h"
cd "$WT/build_make"
profiles=("" "TEST=1")
if [ -n "$MQ" ]; then profiles+=("NET=lwip MQTT=1" "NET=lwip MQTT=1 TEST=1"); fi
for p in "${profiles[@]}"; do
  make -j8 $p > "$S/vb.log" 2>&1; rc=$?
  echo "$BR [$p] rc=$rc warnings=$(grep -ci 'warning' $S/vb.log)"
  grep -iE " error|error:" "$S/vb.log" | head -3
done
"$S/scripts/warncheck.sh" "$WT" "$S/cc_cmd.txt" > "$S/vw.log" 2>&1; echo "$BR warncheck rc=$?"; head -5 "$S/vw.log"
if [ -n "$MQ" ]; then "$S/scripts/warncheck.sh" "$WT" "$S/cc_cmd_mqtt.txt" > "$S/vw.log" 2>&1; echo "$BR warncheck mqtt rc=$?"; head -5 "$S/vw.log"; fi
cd "$WT/testing/host" && make 2>&1 | grep -E "SUMMARY|FAIL|error" ; make clean > /dev/null 2>&1
cd /home/user/INF2004_IS19 && git worktree remove --force "$WT"
