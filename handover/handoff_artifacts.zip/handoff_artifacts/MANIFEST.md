# handoff_artifacts.zip — MANIFEST

Supporting files for the IS19 handover pack (`handover/` in
`purplemushmallow/INF2004_IS19`, commit `58f7d61`). Original filenames are
kept. Nothing here contains Wi-Fi credentials, student IDs, email
addresses, course materials or transcripts; RPT, PREV and the teammate's
ZIPs are listed by hash only. Build trees, binaries and caches are left out.

## Which folder is the master

| Folder | Tree / commit | Status |
|---|---|---|
| `evidence/final_main/` | `b7bf737` (= `main` `58f7d61` except `docs/decisions.md`) | **MASTER** for the current code |
| `evidence/reviewed_merge/` | `698e39d` (teammate's 17 commits + Claude's 2 wording fixes) | superseded by final_main; kept for the review |
| `evidence/teammate_v2/` | TPKG v2 tree `9c3b4113` | review evidence. `host_summary.txt` keeps the first clang SAN=1 line (rc=2, sanitizer runtime missing); `host_clang_san1.log` is the rerun (68 passed) |
| `evidence/per_branch/` | each teammate branch alone | review evidence |
| `evidence/probes/` | probes run on `ee9601b`, `698e39d` (`src_rv_all`) and `main` | `out_ee9601b.txt`/`out_rv_all.txt` = Claude's probe; `out.txt` = teammate's probes on ee9601b and 698e39d; `out_main.txt` = teammate's probes on `58f7d61` |
| `evidence/ee9601b/` | first code, 14 Oct | historical |
| `evidence/template_baseline/` | template only, 13 Oct 09:33Z | historical |
| `evidence/template_import_check.txt` | `e870827` vs uploaded template zip | current |
| `scripts/` | scripts that produced the evidence | current (paths are this container's) |
| `helpers/` | small C/Python helpers (JSON worst case, bounds, header check, mbf sizes, UNVALIDATED list) | current; `sizes_now.c` replaces `superseded/sizes.c` |
| `superseded/` | old `sizes.c` (225 B publish size), 13 Oct base-branch placeholder files, intermediate 13 Oct build logs whose exact tree was not recorded | **do not use as evidence** |
| `history/summary_0938.txt` | first context-compaction summary (13 Oct 09:38Z), holding the never-sent second-round questions | history |

## Sources not included (hash only)

| File | sha256 |
|---|---|
| `2fe3821d-INF2004_final_merged_handoff_1.zip` | `cdf2a74589d40b30080b9e6ec81f5e02beb2a9b9259142b88cccd815cf25bd75` |
| `30357074-INF2004_Design_Review_IS19.zip` | `87dce642f1777084ce0b15230a2ccca1714071a1def9cb63371ac4efd6623cbb` |
| `33f9916c-INF2004_IS19_corrected_v2.zip` | `20cf2b75e9b465d0d6bf5fdb4e600f67a25dcd0cec5abbb241ad9ecc63843852` |
| `5f0dc9a1-IS19_consistency_PRs_v2.zip` | `2666649d17dd53a396c0a7d5640945142e329690c60f711aafa0efe2e0a25602` |
| `815149fa-IS19_Independent_Review_Actions.md` | `57edc0a20abac53f5c9fba9c96a8fe60e032c60d27a3372e1777386339152088` |
| `b5a363a3-Transcript.zip` | `a928cf298b25d89f8922b61c2502b8d6cf52392f1a9065227a9d7611ec58750f` |
| `d18b81e9-Materials_for_project.zip` | `819a2e5f4156fdf6928e129aa8eaa59753a81d79e1a42a1d1da470fedf915bd1` |
| `f7f8f9ac-hardware_images_not_all_are_relevant.zip` | `a8104248afbf5be9a6ad7886c71af8394334275144fdf121410352d69ab73e4d` |
| `fd45f295-INF2004_ProjectTemplate-main.zip` | `918beecbede551f0bf531c8c584a2f3aab8078c351bad15b7743b1a795c5651f` |
| `fed21e50-lectures.zip` | `500df5bfe5b528fb2e2c80b7a0818baf6eb3d0b1a5d49fdb92dee64d1a96667b` |
| `INF2004_Design Review_IS19.pdf` (RPT, inside the RPT zip) | `98bda1250182eb7ff9253dd342d94419bbc1e198b52dc106c021d2763c08c14f` |

PREV per-file hashes (inside `2fe3821d-INF2004_final_merged_handoff_1.zip`):

| File | Bytes | sha256 |
|---|---|---|
| `00_README.md` | 3339 | `e9956d9bccf6b4412fab682b234477140983b8cec567568426d0608611887d54` |
| `01_goal_and_scope.md` | 3276 | `a79b53bcb38dfb7043c88a35deff885be4f3c62133f662d3605e4f1a8ea81bcb` |
| `02_me_and_my_rules.md` | 2440 | `a9fe912c48555b6bc6a829dc33a911ad9fa218550e30542db42cdd6b842a6a10` |
| `03_status.md` | 1739 | `1868478d4e582b84973017d15dfd802d296ed9e99db829874ce98e30977b8470` |
| `04_facts_and_evidence.md` | 8719 | `b69395006c7a228434f838472593410d9cc664e8c1e058a488b0d0c29566612b` |
| `05_decisions.md` | 2639 | `2e95d870890e355dac1ad224d59167ac0ea4f9671334968574258970022c937c` |
| `06_corrections_and_mistakes.md` | 2350 | `0a66f4847c0f16b52af0c5a37ba78f4c3741ba5ca20ca1560f603dd4c50a4be5` |
| `07_dead_ends.md` | 1074 | `e925301813d56dfb524d92bc207d143aca9408640098cc33dba79abe0ed1c9b2` |
| `08_open_questions.md` | 3104 | `69073ce084d8a0aad5b3b70b485d03c37955a2753b0e2cd254c7c6368de46d82` |
| `09_next_steps.md` | 2638 | `3b17078bca2ee831fba7f099feb04c708cd0380b4cba265fc5cc0d9e06711adb` |
| `10_final_content.md` | 2229 | `9500761f20117105864c3dc738f87f4403020d7c4cf3b6277d3683f0ef2c529f` |

## Files in this ZIP

| Path | Bytes | sha256 |
|---|---|---|
| `evidence/ee9601b/build_NET_lwip_MQTT_1.log` | 641965 | `b0adfa89837a8e1a5d9d5555085cecfb39f62ee4bf5fcec909b8481984257f6e` |
| `evidence/ee9601b/build_NET_lwip_MQTT_1_TEST_1.log` | 642005 | `8693d8acfefbb6b72caf516cbc85793d5ae1c955d5b101d7a94320998e744517` |
| `evidence/ee9601b/build_SMP_0.log` | 491046 | `25bd36fd13d4f47c1a368ff579ba869ecfc0e80cd06ce61a966fe2935d16de83` |
| `evidence/ee9601b/build_TEST_1.log` | 492706 | `ba703778612ebd64a2f8c9f3c9a81e3f83d7ee78a449f6fef1bce90a5f39e74b` |
| `evidence/ee9601b/build_WIFI_none.log` | 204254 | `bf8850cdb10b778c4f657ade728276191904dd943a41e377835ac9b3a400404e` |
| `evidence/ee9601b/build_default.log` | 492781 | `4168cdc777a03511494b71dc1b2dc1742514789e7f4d71ecc2b32a26939c3da8` |
| `evidence/ee9601b/build_summary.txt` | 1479 | `33f4fd3d96b0c77236fb3ebd0b2535dc0834b1b02cf948a39ed62fde652fcd0f` |
| `evidence/ee9601b/env.txt` | 485 | `cc2ef6a5897baea2a3de72e35764de1cd34d9939deb9c09d90b25fcff2eaafcd` |
| `evidence/ee9601b/host_cc.log` | 5030 | `d1cf8e2214c9ff1dc53f0f8d85afa0ea9d2dc7e9ea94873cea3a246a7917f127` |
| `evidence/ee9601b/host_clang.log` | 5033 | `2abd11ad1f19109dc2842ccf6418837230b4fda273bc1b8c0c39ce8d73d13fe1` |
| `evidence/ee9601b/host_gcc_san.log` | 5110 | `8f3fa0caee5c94f886ac3871875b6aea6c98e9322986b141cf9f554890088afe` |
| `evidence/ee9601b/host_summary.txt` | 197 | `714f8e2ec80d1b5ab790677636b8648e0878830ec48ea68150b749e80eb77b41` |
| `evidence/ee9601b/mbf_sizes_now.txt` | 561 | `770954285ce1db1915cb48393e9699476852207f0cfecf20773d89dcacced4b0` |
| `evidence/ee9601b/repo_path_sizes.txt` | 352 | `07bb22cd6c51765528a78af0f659cd1420b6a9613688b0a8815f46622f0c5375` |
| `evidence/ee9601b/warncheck_cc_cmd.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/ee9601b/warncheck_cc_cmd_mqtt.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/ee9601b/warncheck_cc_cmd_mqtt_test.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/ee9601b/worst_case_json.txt` | 1503 | `bab7916adcfb0a0a19544a8c1c80baed4c24afe9d76da86bc7ec5234dddbfd07` |
| `evidence/final_main/build_CONSOLE_uart_WIFI_none.log` | 64571 | `0571ffd9e862f27ffac60c508c4fcf9fcde3da56daf5fcaae5aad7aebec3fe87` |
| `evidence/final_main/build_CRASH_REPORT_1.log` | 489900 | `b6c057170aa6d9aa4ff1758adbd0882a9de6fb52abc9a4ccbeb0825a79e32c37` |
| `evidence/final_main/build_NET_lwip_MQTT_1.log` | 641965 | `4335336090041a50c618d2d0d32bf09d256e7ab83c4b9f3798953e33d4710d15` |
| `evidence/final_main/build_NET_lwip_MQTT_1_TEST_1.log` | 642005 | `8954064ea522408ef6b88924a38004ab236c6e65cf0874c953a8535501792eb5` |
| `evidence/final_main/build_SMP_0.log` | 491046 | `c852d4bdcaaa5c9aa1836aab1ae9324424dafdf6a041c764ba466c71cd697e9f` |
| `evidence/final_main/build_TEST_1.log` | 492706 | `591313678c4b33ac38e24d19865c1c33cf630b51146414ebc1ebaa09597afbd0` |
| `evidence/final_main/build_default.log` | 492781 | `5ac023304b817ab62e14234e34d87c033b7dbcb4dc1816c684eab81e253ccbbd` |
| `evidence/final_main/build_summary.txt` | 482 | `c5e51f4996ba47cb1662f377a1df6a4ba13adc2339593981898b6f005e2f6890` |
| `evidence/final_main/final2_head.txt` | 41 | `80675090d06c20fd80d451271356786ec1f90c92eaec7c4e9a3d55ba8675f0ea` |
| `evidence/final_main/host_clang_san0.log` | 6193 | `435fecc9d16b94d10a1d20b8c56b2e5623e78e1982eb7f789a7f949ee9468450` |
| `evidence/final_main/host_clang_san1.log` | 6351 | `af76cb8a4548c8bba7346b262a220a05753836c1b9417f8d6bb10578c61c2671` |
| `evidence/final_main/host_gcc_san0.log` | 6196 | `88f789716410920b8598923ef0a62f494385eb123db3cf337e0f6fc143005865` |
| `evidence/final_main/host_gcc_san1.log` | 6354 | `d9f1248782c2aa539cdfe271da9af8429f009c012154765d2487aa774bb852a3` |
| `evidence/final_main/host_summary.txt` | 244 | `c061778c15b744a2ceae5fda9599228454ba50bbf00e4ded1f6e3c16f988b3df` |
| `evidence/final_main/host_test_list.txt` | 4541 | `e39d13bbbe191be35a3ea464435b35f79a01ad98452603155daf5b811f0f80f9` |
| `evidence/final_main/unvalidated_settings.txt` | 2436 | `5edb1e956f145263313ac6cfe4b8f0c0093ba9af18ff4712fabdc449f9724a8e` |
| `evidence/final_main/warncheck_cc_cmd.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/final_main/warncheck_cc_cmd_mqtt_test.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/per_branch/pb_build_mqtt_s1.log` | 641965 | `63f0f99f7c89d440b2a7b787a19c34eb22b40fa5b33ceaac3effa0abf0ba463d` |
| `evidence/per_branch/pb_build_mqtt_s2.log` | 641965 | `0a25717cfbcef7866acfce31336ba8d8375b1dd2dd1344cbd31d05ec5f93d426` |
| `evidence/per_branch/pb_build_mqtt_s3.log` | 641965 | `90bcfee86d6bd9eab5f44db73d9fa36c1f000d86239c8f63cf196044c9f86b54` |
| `evidence/per_branch/pb_build_mqtt_s4.log` | 641965 | `9da1f81b1e0ecbc155f6b766f0e1b952543b0eaa98fa9f6fcff265b1e489c626` |
| `evidence/per_branch/pb_build_mqtt_s5.log` | 641965 | `e1bbce6a31d19f879f336a08a06c56f3d669e4d4633b5b968e12aec4d89774a5` |
| `evidence/per_branch/pb_build_mqtt_shared.log` | 641965 | `9311e069df354ba4ec78f0ef72608caa1de68bf21297a9219b86771c6581d552` |
| `evidence/per_branch/pb_build_s1.log` | 492781 | `fb76152d9d7ce93ed1adf4918bf63f705cde13fa31510dbe9433c6377fccebb5` |
| `evidence/per_branch/pb_build_s2.log` | 492781 | `839ae0bced76d875334c6c20137e8b85450c0bf152d65dcf48355fd91518e15c` |
| `evidence/per_branch/pb_build_s3.log` | 492781 | `c79d4f47fd50089393a36c554eaf47118430c02bbd92dbd57ee9c4ab022a17cb` |
| `evidence/per_branch/pb_build_s4.log` | 492781 | `30cef68f8f3aac7eba6f8cd8ecb6665b644cd4d0555374ed5cc1bd04f9d48246` |
| `evidence/per_branch/pb_build_s5.log` | 492781 | `6579dd271bdad76ec5582f7181857f72a6d7cff4a3ba3203d4c5fb52ed3edcba` |
| `evidence/per_branch/pb_build_shared.log` | 492781 | `990f24e08e6a16975192fc17b79a07a905830c14c6f1b9179d53b7d1654956b6` |
| `evidence/per_branch/pb_host_s1.log` | 5524 | `a4a279f66210562bc11cd5f5ea9192b5dde89a7fb98ef386997f0b7dd2673f53` |
| `evidence/per_branch/pb_host_s2.log` | 5436 | `7e3785ae44463e7a7a9a143aa0068c4e222b8a65c848ccaaf7156bea82e8393f` |
| `evidence/per_branch/pb_host_s3.log` | 5687 | `72678a51e6c3448401fb925be79c1b65421296015317232d3714fef7c9fbc074` |
| `evidence/per_branch/pb_host_s4.log` | 5436 | `7e3785ae44463e7a7a9a143aa0068c4e222b8a65c848ccaaf7156bea82e8393f` |
| `evidence/per_branch/pb_host_s5.log` | 5630 | `dae47ee2ed0172738b1f67993b5fdc5841f80ec1892e7d805e1e3180eb9cd2a3` |
| `evidence/per_branch/pb_host_shared.log` | 5436 | `7e3785ae44463e7a7a9a143aa0068c4e222b8a65c848ccaaf7156bea82e8393f` |
| `evidence/per_branch/per_branch.txt` | 815 | `e442f0240b4e13ac1da56e79dcbd68482e3a1441da7faf590cdb5a55cae5f71a` |
| `evidence/probes/out.txt` | 1701 | `9e489958d0c67489cf6b48575aa4572baf9e9b43f629071ddb46e4e1b5949d2c` |
| `evidence/probes/out_ee9601b.txt` | 215 | `707c7c6f2005b8b8d58d392fba38c1f4c871e1b2619229660e24c6a177bda6db` |
| `evidence/probes/out_main.txt` | 844 | `b336f3873ae36549b82fc50e1a146730fc319f267220d31d4f0b9206908b4482` |
| `evidence/probes/out_rv_all.txt` | 215 | `4769d9f120860f4f05849e3fa3086063de33b385bbb4fab6444005f278f9e355` |
| `evidence/probes/probe_claims.c` | 5306 | `3ce9d47d9d88b6d049c13a56093925c27e55c7546fa8c3b63c769c5bd7cc1f34` |
| `evidence/probes/probe_mine.c` | 4256 | `98adc602ad33147081d2d7c8b7448208a21536b46720bd2ac69af97122fa1019` |
| `evidence/probes/probe_nav_i05.c` | 2577 | `4e05f65ae063dd2bc19be8a939a3372cf15703364cfd152b92618f20c3818b7e` |
| `evidence/probes/run_probes.sh` | 1056 | `cc0ed5fb3e6f13befdcf8fc9917bdc978cbe7beddf0318d3651643e2f6a82cb9` |
| `evidence/reviewed_merge/build_CONSOLE_uart_WIFI_none.log` | 64571 | `5f8716d60cca1eae3788f54347847e50df70e129801f272e64057103ada34016` |
| `evidence/reviewed_merge/build_CRASH_REPORT_1.log` | 489900 | `3fa30c9a7486ec80aca46c1fb81c4286aa456fcfbc3ea7156e5f934116536563` |
| `evidence/reviewed_merge/build_NET_lwip_MQTT_1.log` | 641965 | `8d22fcb1edb44cdf692456a986b113c78622f8951144c6a069f188438af595bc` |
| `evidence/reviewed_merge/build_NET_lwip_MQTT_1_TEST_1.log` | 642005 | `9c5d0b1d4b3c377bccfdddf23b47c3940e9554102f0f5f620fb291078d3af0ae` |
| `evidence/reviewed_merge/build_SMP_0.log` | 491046 | `1dcd20c5037960b42270f4590ba4b2525bd80148b405359ad2a39767012f1b48` |
| `evidence/reviewed_merge/build_TEST_1.log` | 492706 | `2976ee736c8fdf5ac78560d2adcd59b2db528028427f5f8de39506a69e30cf87` |
| `evidence/reviewed_merge/build_default.log` | 492781 | `264455b7696ff19aa572d25477931d179a64ec2738e3430236fe93e06accb1fc` |
| `evidence/reviewed_merge/build_summary.txt` | 482 | `c34c0378f53ca1161bc9f954dfab1a7c914f9468d82d43aa8fd69cddc8ec8571` |
| `evidence/reviewed_merge/final_head.txt` | 41 | `997cde63d8742bada2e458119e667dcc8309d8522f13799486d3427aadad4028` |
| `evidence/reviewed_merge/host_clang_san0.log` | 5880 | `b702bf2eee2f8d7b0e0df0ed63d613dae95590b3c0f25f6c5be6fd47bbb15226` |
| `evidence/reviewed_merge/host_clang_san1.log` | 6038 | `13a372b1c6fb39ad544ed58e8a09f23bb6232f52b52045bc2038aa66108c8523` |
| `evidence/reviewed_merge/host_gcc_san0.log` | 5883 | `679a08082bc11568a68eca67cf5e2741baff88b5422533af4c1c4b601b360283` |
| `evidence/reviewed_merge/host_gcc_san1.log` | 6041 | `0b72207413fba87e49ca7acd114aa1c34bd665323a23e235cb340068c05fb58c` |
| `evidence/reviewed_merge/host_summary.txt` | 244 | `ef1a7fefe9c971bfcd7e4a3e5a0c61a11816da17b861c8024fb17c29c4c80f6e` |
| `evidence/reviewed_merge/warncheck_cc_cmd.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/reviewed_merge/warncheck_cc_cmd_mqtt_test.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/teammate_v2/build_CONSOLE_uart_WIFI_none.log` | 64571 | `11f7c18682d96c84655f7fb311f67184ecf32408125566250641ea25f105fedc` |
| `evidence/teammate_v2/build_CRASH_REPORT_1.log` | 489900 | `afcaa7d3174b1b7b3f951b6a2c91704a60c73ab5c59cc7257d51248008a0ed9c` |
| `evidence/teammate_v2/build_NET_lwip_MQTT_1.log` | 641965 | `fbcbd37f02e724dfc373c53f3c9f084810830436f050cff82df19419a0654ccf` |
| `evidence/teammate_v2/build_NET_lwip_MQTT_1_TEST_1.log` | 642005 | `b82f3352f58243bed0602c21f9366bca40c41ff68e3387458f3e3870c70ada48` |
| `evidence/teammate_v2/build_SMP_0.log` | 491046 | `3bffaf80c22d8ddb071820e57f781f8bf912fdbe851de960a96468aa08abdd68` |
| `evidence/teammate_v2/build_TEST_1.log` | 492706 | `287791d9910b0f22874d64604f0141da41d4a6290bf9b0b93d5c73145aaa0fa2` |
| `evidence/teammate_v2/build_default.log` | 492781 | `40838db2e3013d0c52dd908bbb8a4abbaed64f1dcf921f533325ac52293c5d55` |
| `evidence/teammate_v2/build_summary.txt` | 482 | `c34c0378f53ca1161bc9f954dfab1a7c914f9468d82d43aa8fd69cddc8ec8571` |
| `evidence/teammate_v2/host_clang_san0.log` | 5880 | `b702bf2eee2f8d7b0e0df0ed63d613dae95590b3c0f25f6c5be6fd47bbb15226` |
| `evidence/teammate_v2/host_clang_san1.log` | 6038 | `13a372b1c6fb39ad544ed58e8a09f23bb6232f52b52045bc2038aa66108c8523` |
| `evidence/teammate_v2/host_gcc_san0.log` | 5883 | `679a08082bc11568a68eca67cf5e2741baff88b5422533af4c1c4b601b360283` |
| `evidence/teammate_v2/host_gcc_san1.log` | 6041 | `0b72207413fba87e49ca7acd114aa1c34bd665323a23e235cb340068c05fb58c` |
| `evidence/teammate_v2/host_summary.txt` | 205 | `eebed1ba895ea7e68377d9077b3790bf37cebfcad9c6cbb7cbc586c93c9547f3` |
| `evidence/teammate_v2/warncheck_cc_cmd.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/teammate_v2/warncheck_cc_cmd_mqtt_test.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `evidence/template_baseline/baseline_default.log` | 363974 | `26e9b29f9ca186ca6bd5649907d62337a509b5e32c909e24806f6b176a39dd84` |
| `evidence/template_baseline/baseline_mqtt.log` | 507488 | `f0150f158ae32e5d75a81ab30dfe9e31f8749295784c682504ea952a938e996e` |
| `evidence/template_baseline/baseline_mqtt_test.log` | 507528 | `0e4c1349b59e96bb1f858c120be8db83fe4ff411a2e55c1af49a45ed3b96bc19` |
| `evidence/template_import_check.txt` | 302 | `8728feef3262ede37ccd13e96366a504354b34eba45c3414d8448cf9f4e7a476` |
| `helpers/bound.c` | 1071 | `b53068efdc6dac3129ce1fd554259a1e070a48b568731d250e9a142adabd888c` |
| `helpers/cfg_table.py` | 1526 | `3dc050e90e89231dcd9179e2d14384ce5d0418e80bede5036d7882b1938f129e` |
| `helpers/hdrtest.c` | 204 | `83455196f45691c09121b99488293237a8d22868b7bfe7e9f8e26c1bd27a11c5` |
| `helpers/sizes_now.c` | 1288 | `f7663dae6a4184c80ee15bb6b73c8200a8fee888ea535483b73243096157da83` |
| `helpers/unval.py` | 728 | `2e2ed3cb7a4e5fcb55fcbaf249f4509f46fc7d7ee8cd42e61744a12be426c64e` |
| `helpers/worst.c` | 2548 | `6030b0b3a5735b23991839f834ef9ecac2fa6bbe2cebc6b0f2fc6c52d4f30383` |
| `history/summary_0938.txt` | 19552 | `4b2e3225ec0af78657ac95d801b31de9475cd814f048748bfbbeae5f0214779c` |
| `scripts/bars.py` | 2002 | `2d3e629d26ed13cc2d761b11b1f639fede811f3f649d602cfca3d45a891e4472` |
| `scripts/cc_cmd.txt` | 3471 | `76c5b3745ac14a534d817d261020400d782a491b9da98ab06f344b96faa996bf` |
| `scripts/cc_cmd_mqtt.txt` | 3633 | `6ee3e179545f41dc36fdecfd138e7a57203fc97a0b0b7ccaf1677ecee3f44c5b` |
| `scripts/cc_cmd_mqtt_test.txt` | 3633 | `5f5c08ab8d441a8b7285018db728913b6cf49b7cc5adfa16d2fe82bae19f7fa3` |
| `scripts/collect_evidence.sh` | 3014 | `00fc4b3d9e18e4aead0a944c8862c1abd2077f0df92daf836676a4752bd9f4a4` |
| `scripts/contact.py` | 492 | `a13b7b0585fabf0eb8d3ca75c4ec0923ee115932c3be4176544268e13d57be29` |
| `scripts/gen_testlogs.py` | 16517 | `c0c580990d0815a702a0842524b98ac23b05dca88778c9ff0316abeeaeea96ae` |
| `scripts/gen_testlogs2.py` | 7905 | `ab3771650ad89a15620c24371cb0c5e16374951a07eb7ad0e18bfa5cdc2a405f` |
| `scripts/per_branch.sh` | 989 | `615dce31ce011be99671d95d70f3a13acec137b925fc741d2eb1360afa7a6782` |
| `scripts/sheet2.py` | 554 | `efd92a48faebb403ad5ebb49d0f2a257ece20d3029178bd93c21a7ccde3bc0dc` |
| `scripts/verify_branch.sh` | 1095 | `9a06bd98e92e52f0e0dd864232dbffe05e1e1b0b5b8b54437ca54a64d3aeddfa` |
| `scripts/verify_tree.sh` | 1403 | `857c83e666b45f5f8374a21c74e8fcee83178d53e3643ae76c15828e53117e12` |
| `scripts/warncheck.sh` | 647 | `27c0fc92995a5b0a15bad3ab8ae660ed7afd5447d92b71e6038cd0da7c8d1dfb` |
| `superseded/base_branch_placeholders/subsystem1/subsystem1.c` | 715 | `bbaade6d359efdda1aa8430cfeb5d9781c842ec4867524b773c1310e50edff59` |
| `superseded/base_branch_placeholders/subsystem1/subsystem1_test.c` | 346 | `e30573ceb2c3204ca5016dc869a420b7499a4402dd7223f2430a551b0ce34879` |
| `superseded/base_branch_placeholders/subsystem2/subsystem2.c` | 1494 | `36830d34b7fcdec3e4a82f7d5255474fc5f224956501b9ed70026062447e8345` |
| `superseded/base_branch_placeholders/subsystem2/subsystem2_test.c` | 346 | `7cba5385df84a2c183edddaa6f3c11b14e22caa66c5c6463746232c3211f60f2` |
| `superseded/base_branch_placeholders/subsystem3/subsystem3.c` | 959 | `d1a13bef86ac1601f04633af631ed752f75c250b13f1e906f21563d3d18039cd` |
| `superseded/base_branch_placeholders/subsystem3/subsystem3_test.c` | 346 | `f886be7a419b08119369eb20cee233323b7d7f47e0bc4a6ebcd2fbaebe6d8dcd` |
| `superseded/base_branch_placeholders/subsystem4/subsystem4.c` | 862 | `3a48fc0c8785f3c62d5b1e8279128868b70c00fbabe4d560a8a0322c6af3cb6a` |
| `superseded/base_branch_placeholders/subsystem4/subsystem4_test.c` | 346 | `a597514d8e8cf96c3be500f20e0e164557ddea845a27d4d377437810b13982e9` |
| `superseded/base_branch_placeholders/subsystem5/subsystem5.c` | 531 | `60bbb7bbc8c108c573f0a65e0a5255d25a35f3a90de5334fe435beb3e7543511` |
| `superseded/base_branch_placeholders/subsystem5/subsystem5_test.c` | 346 | `cb8260c043e147f7b758096f1294d015db6392216e7cfe148c324a34148a18c6` |
| `superseded/intermediate_build_logs/b.log` | 642005 | `485757192dfcc160c46d2f6a1159f97561e3f8311cd817dc095a58b76afdfb19` |
| `superseded/intermediate_build_logs/b0.log` | 491046 | `62a24fdda2e19eef3808a62ac34c7256f608a7a5bb66a98b982f53d0f42b8881` |
| `superseded/intermediate_build_logs/base.log` | 534144 | `0540ea9afb53d0e3cae93917987958ed36a4376be6eb0474aa351fa914c4b12f` |
| `superseded/intermediate_build_logs/bn.log` | 204254 | `3ddfbab33ad01bb10ad990bfc26d09589946397bf48c336d28e2388580bce5c3` |
| `superseded/intermediate_build_logs/build_mqtt.log` | 641965 | `7acb99c640d316c96d7f86df126017b02ee8f5930905c02e3c78f639c113d426` |
| `superseded/intermediate_build_logs/build_mqtt_test.log` | 642005 | `c7f7496ed934551cc0ad6020fb65ea0682a920d092da67cc8d5e796893bc5422` |
| `superseded/intermediate_build_logs/build_test.log` | 492706 | `f8171104ad5d6fa4a90cf74e91d4043aef3f10d9f3f130cc3516c31dc4b674f4` |
| `superseded/intermediate_build_logs/vb.log` | 404183 | `68e7872aef653a2a96e21ff58659405a5ad74b58bf3392ff139a3d53f8e987d7` |
| `superseded/intermediate_build_logs/vw.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `superseded/sizes.c` | 1227 | `dc4cde772d15ad5880269d622547d3b9af87aa7cbf1c8c99cebd15913b040e37` |
