/*
 *  subsystem5.c
 *  Subsystem 5 (Buddy 5): PLACEHOLDER until the Buddy 5 pull request.
 *
 *  Provides the interface in subsystem5.h with no behaviour.  Buddy 5's
 *  pull request replaces this file with the Obstacle Scan task.
 */

#include "subsystem5.h"

EXPORT ID mbf_scan_req = 0;

EXPORT ER
subsystem5_init (void)
{
    return (E_OK);
}

EXPORT ER
subsystem5_start (void)
{
    return (E_OK);
}

ER
scan_request (uint8_t type, uint8_t side)
{
    (void) type;
    (void) side;
    return (E_OK);
}

/*** end of file ***/
