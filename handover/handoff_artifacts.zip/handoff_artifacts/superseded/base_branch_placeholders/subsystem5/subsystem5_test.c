/*
 *  subsystem5_test.c
 *  On-target tests for subsystem 5.  Built only with: make TEST=1
 *  PLACEHOLDER until the Buddy 5 pull request.
 */

#include "../test_report.h"
#include "subsystem5.h"

#if APP_TEST

EXPORT void
subsystem5_test (void)
{
    TEST_INIT();
    TEST_SUMMARY("subsystem5");
}

#endif /* APP_TEST */

/*** end of file ***/
