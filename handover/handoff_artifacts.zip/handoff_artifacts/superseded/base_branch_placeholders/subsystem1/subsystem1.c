/*
 *  subsystem1.c
 *  Subsystem 1 (Buddy 1): PLACEHOLDER until the Buddy 1 pull request.
 *
 *  Provides the interface in subsystem1.h with no behaviour, so the
 *  shared code builds and runs on its own.  Buddy 1's pull request
 *  replaces this file with the Command and Telemetry tasks.
 */

#include "subsystem1.h"

EXPORT ID mbf_tlm      = 0;
EXPORT ID mbf_publish  = 0;
EXPORT ID mbf_cmd_in   = 0;
EXPORT ID mbf_mqtt_cfg = 0;

EXPORT ER
subsystem1_init (void)
{
    return (E_OK);
}

EXPORT ER
subsystem1_start (void)
{
    return (E_OK);
}

/* Placeholder: telemetry records are dropped. */
void
tlm_post (tlm_msg_t * p_msg, bool b_urgent)
{
    (void) p_msg;
    (void) b_urgent;
}

/*** end of file ***/
