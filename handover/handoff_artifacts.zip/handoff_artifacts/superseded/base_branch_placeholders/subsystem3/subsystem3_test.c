/*
 *  subsystem3_test.c
 *  On-target tests for subsystem 3.  Built only with: make TEST=1
 *  PLACEHOLDER until the Buddy 3 pull request.
 */

#include "../test_report.h"
#include "subsystem3.h"

#if APP_TEST

EXPORT void
subsystem3_test (void)
{
    TEST_INIT();
    TEST_SUMMARY("subsystem3");
}

#endif /* APP_TEST */

/*** end of file ***/
