/*
 *  subsystem3.c
 *  Subsystem 3 (Buddy 3): PLACEHOLDER until the Buddy 3 pull request.
 *
 *  Provides the interface in subsystem3.h with no behaviour: the line
 *  record is never valid, so Navigation never steers.  The steering and
 *  letter-map code Navigation runs (steering.c, letter_map.c) is already
 *  the real code.  Buddy 3's pull request replaces this file with the
 *  Line task.
 */

#include "subsystem3.h"

EXPORT ER
subsystem3_init (void)
{
    return (E_OK);
}

EXPORT ER
subsystem3_start (void)
{
    return (E_OK);
}

/* Placeholder: an empty record (b_valid = 0). */
ER
line_err_read (line_err_t * p_out)
{
    ER ercd = E_PAR;

    if (NULL != p_out)
    {
        line_err_t const empty = { 0 };

        *p_out = empty;
        ercd   = E_OK;
    }

    return (ercd);
}

void
line_set_adaptation (bool b_enable)
{
    (void) b_enable;
}

void
line_set_run_over (bool b_run_over)
{
    (void) b_run_over;
}

/*** end of file ***/
