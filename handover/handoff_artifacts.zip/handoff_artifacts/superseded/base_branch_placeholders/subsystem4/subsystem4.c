/*
 *  subsystem4.c
 *  Subsystem 4 (Buddy 4): PLACEHOLDER until the Buddy 4 pull request.
 *
 *  Provides the interface in subsystem4.h with no behaviour: faults are
 *  ignored and the watchdog is not started.  Buddy 4's pull request
 *  replaces this file with the Safety and IMU tasks.
 */

#include "subsystem4.h"

EXPORT ID flg_safety = 0;
EXPORT ID mbf_fault  = 0;

EXPORT ER
subsystem4_init (void)
{
    return (E_OK);
}

EXPORT ER
subsystem4_start (void)
{
    return (E_OK);
}

void
safety_report_fault (uint8_t cause, uint8_t source, uint16_t detail)
{
    (void) cause;
    (void) source;
    (void) detail;
}

bool
safety_is_faulted (void)
{
    return (false);
}

void
safety_checkin (uint32_t checkin_bit)
{
    (void) checkin_bit;
}

void
safety_ack_zero (void)
{
}

void
safety_set_imu_ok (bool b_ok)
{
    (void) b_ok;
}

/*** end of file ***/
