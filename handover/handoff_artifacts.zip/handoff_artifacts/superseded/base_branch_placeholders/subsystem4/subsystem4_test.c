/*
 *  subsystem4_test.c
 *  On-target tests for subsystem 4.  Built only with: make TEST=1
 *  PLACEHOLDER until the Buddy 4 pull request.
 */

#include "../test_report.h"
#include "subsystem4.h"

#if APP_TEST

EXPORT void
subsystem4_test (void)
{
    TEST_INIT();
    TEST_SUMMARY("subsystem4");
}

#endif /* APP_TEST */

/*** end of file ***/
