/*
 *  subsystem2.c
 *  Subsystem 2 (Buddy 2): PLACEHOLDER until the Buddy 2 pull request.
 *
 *  Provides the interface in subsystem2.h with no behaviour: commands
 *  are accepted and ignored, and the motors are never driven.  Buddy 2's
 *  pull request replaces this file with the Motion task.
 */

#include "../subsystem4/subsystem4.h"
#include "subsystem2.h"

EXPORT ID mbf_motion_cmd = 0;
EXPORT ID flg_motion     = 0;

EXPORT ER
subsystem2_init (void)
{
    return (E_OK);
}

EXPORT ER
subsystem2_start (void)
{
    return (E_OK);
}

ER
motion_drive (int32_t speed_mmps, int32_t diff_mmps)
{
    (void) speed_mmps;
    (void) diff_mmps;
    return (E_OK);
}

ER
motion_move_forward (int32_t distance_mm, uint8_t move_id)
{
    (void) distance_mm;
    (void) move_id;
    return (E_OK);
}

ER
motion_move_backward (int32_t distance_mm, uint8_t move_id)
{
    (void) distance_mm;
    (void) move_id;
    return (E_OK);
}

ER
motion_turn_left (int32_t angle_cdeg, uint8_t move_id)
{
    (void) angle_cdeg;
    (void) move_id;
    return (E_OK);
}

ER
motion_turn_right (int32_t angle_cdeg, uint8_t move_id)
{
    (void) angle_cdeg;
    (void) move_id;
    return (E_OK);
}

ER
motion_stop (void)
{
    return (E_OK);
}

ER
motion_hold_speed (bool b_hold)
{
    (void) b_hold;
    return (E_OK);
}

ER
motion_keepalive (void)
{
    return (E_OK);
}

/* Placeholder: nothing to clear, acknowledge at once. */
void
motion_request_reset (void)
{
    safety_ack_zero();
}

/*** end of file ***/
