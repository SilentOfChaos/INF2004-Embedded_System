/*
 *  subsystem2_test.c
 *  On-target tests for subsystem 2.  Built only with: make TEST=1
 *  PLACEHOLDER until the Buddy 2 pull request.
 */

#include "../test_report.h"
#include "subsystem2.h"

#if APP_TEST

EXPORT void
subsystem2_test (void)
{
    TEST_INIT();
    TEST_SUMMARY("subsystem2");
}

#endif /* APP_TEST */

/*** end of file ***/
