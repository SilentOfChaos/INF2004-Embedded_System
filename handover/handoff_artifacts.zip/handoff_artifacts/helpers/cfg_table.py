import re,sys
src=open(sys.argv[1],encoding='utf-8').read().splitlines()
section=''; comment=[]; rows=[]
in_c=False; cur=[]
for line in src:
    s=line.strip()
    m=re.match(r'/\*\s*=+',s)
    if re.match(r'\*\s+\d+\.\s',s) and not in_c:
        pass
    sec=re.match(r'^\*\s+(\d+\.\s.*)$',s)
    if sec and '=====' not in s:
        section=sec.group(1).strip()
    if s.startswith('/*'):
        in_c=True; cur=[s]
        if s.endswith('*/'): in_c=False; comment=cur[:]
        continue
    if in_c:
        cur.append(s)
        if s.endswith('*/'): in_c=False; comment=cur[:]
        continue
    d=re.match(r'#define\s+(CFG_\w+)\s+(.+?)\s*(/\*(.*?)\*/)?\s*$',s)
    if d:
        name,val,_,trail=d.groups()
        text=' '.join(comment)+' '+(trail or '')
        tags=[]
        for t in re.findall(r'\[(REPORT[^\]]*|DATASHEET[^\]]*|TEMPLATE[^\]]*|DECISION[^\]]*|UNVALIDATED[^\]]*)\]',text,re.S):
            t=re.sub(r'\s+',' ',t)
            key=t.split(':')[0].split(' (')[0]
            key=key if len(key)<40 else key[:40]
            tags.append(key.strip())
        rows.append((section,name,val.strip(),'; '.join(dict.fromkeys(tags)) or '(see comment)'))
        continue
    if s=='' : comment=comment  # keep comment for following define groups
cur_sec=None
for sec,name,val,tag in rows:
    if sec!=cur_sec:
        print(f"\n**{sec}**\n\n| Setting | Value | Basis tag in `app_config.h` |\n|---|---|---|"); cur_sec=sec
    print(f"| `{name}` | `{val}` | {tag} |")
print(f"\n<!-- {len(rows)} settings -->")
