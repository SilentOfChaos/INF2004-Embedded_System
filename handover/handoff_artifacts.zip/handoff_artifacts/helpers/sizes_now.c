#include <stdio.h>
#include "subsystem1/tlm_msgs.h"
#include "subsystem2/motion_msgs.h"
#include "subsystem3/line_msgs.h"
#include "subsystem4/imu_msgs.h"
#include "subsystem5/scan_msgs.h"
#include "app_config.h"
typedef struct { char ip[16]; uint16_t port; } comms_broker_t;
typedef struct { uint32_t time_us; uint8_t b_dark; uint8_t reserved[3]; } barcode_edge_t;
typedef struct { uint32_t rise_us; uint32_t fall_us; } echo_guess_t;
#define O 8u
int main(void){
 unsigned t=0, v;
#define M(name,sz,depth) v=(unsigned)((depth)*((sz)+O)); t+=v; printf("%-16s %3u x (%3u+8) = %5u\n", name,(unsigned)(depth),(unsigned)(sz),v);
 M("mbf_line_evt", sizeof(line_evt_t),16)
 M("mbf_imu_evt", sizeof(imu_evt_t),16)
 M("mbf_obstacle", sizeof(obstacle_evt_t),8)
 M("mbf_motion_sts", sizeof(motion_sts_t),16)
 M("mbf_nav_cmd", sizeof(nav_cmd_t),8)
 M("mbf_motion_cmd", sizeof(motion_cmd_t),16)
 M("mbf_scan_req", sizeof(scan_req_t),8)
 M("mbf_fault", sizeof(fault_evt_t),16)
 M("mbf_tlm", sizeof(tlm_msg_t),24)
 M("mbf_publish", (1u + CFG_MQTT_PAYLOAD_MAX),8)
 M("mbf_cmd_in", CFG_MQTT_CMD_MAX,4)
 M("mbf_mqtt_cfg", sizeof(comms_broker_t),2)
 printf("line edges 1024 (64 x 16)\n"); t+=1024;
 printf("echo (see drv_ultrasonic.h) 8 x (size+8)\n");
 printf("total (without echo) %u\n", t);
 return 0;}
