import re,sys
src=open(sys.argv[1]).read().split('\n')
out=[];comment=[];inc=False
for ln in src:
    s=ln.strip()
    if s.startswith('/*') and not s.startswith('/* ==') :
        comment=[s];inc=not s.endswith('*/')
        continue
    if inc:
        comment.append(s); inc=not s.endswith('*/'); continue
    m=re.match(r'#define\s+(CFG_\w+)\s+(.*?)\s*(/\*(.*)\*/)?\s*$',s)
    if m:
        c=' '.join(comment)
        tag='UNVALIDATED' in c or (m.group(4) and 'UNVALIDATED' in m.group(4))
        out.append((m.group(1),m.group(2),tag))
    elif s=='' : pass
    elif not s.startswith('#'): comment=[]
n=sum(1 for o in out if o[2])
print("defines",len(out),"unvalidated",n)
for o in out:
    if o[2]: print(o[0],'=',o[1])
