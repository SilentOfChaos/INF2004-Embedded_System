#include <stdio.h>
#include "subsystem1/tlm_format.h"
#include "subsystem4/imu_msgs.h"
int main(void){
  static tlm_state_t st; char buf[1024]; uint32_t n;
  tlm_state_init(&st);
  st.p_mode_name="AVOIDING OBSTACLE";
  st.motion.speed_l_mmps=-32768; st.motion.speed_r_mmps=-32768;
  st.motion.count_l=-9999999; st.motion.count_r=-9999999; st.motion.distance_mm=-9999999;
  st.line.raw_l=-32768; st.line.raw_r=-32768; st.line.error_pm=-32768; st.line.letters=255; st.line.last_letter='Z';
  st.imu.humps=255; st.imu.max_height_mm=-32768; st.scan.obstacles=65535; st.scan.range_mm=-32768;
  st.imu.motion_class=IMU_CLASS_ACCELERATING; st.imu.turn_rate_dps=-32768;
  n=tlm_format_telemetry(&st,9999999u,99999999u,buf,sizeof buf); printf("telemetry bound %u\n%s\n",n,buf);
  st.dropped=UINT32_MAX; st.link.wifi_status=-3; st.nav.held_letter='Z'; st.nav.hold_reason=2; st.safety.cause=6; st.safety.queue_full=255; st.safety.missed_checkins=65535;
  n=tlm_format_heartbeat(&st,9999999u,99999999u,9999999u,buf,sizeof buf); printf("heartbeat bound %u\n%s\n",n,buf);
  return 0;}
