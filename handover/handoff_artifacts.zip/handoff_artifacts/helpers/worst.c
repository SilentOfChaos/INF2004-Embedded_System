#include <stdio.h>
#include <string.h>
#include "subsystem1/tlm_format.h"
#include "subsystem4/imu_msgs.h"
int main(void){
  static tlm_state_t st; char buf[1024]; uint32_t n;
  tlm_state_init(&st);
  st.p_mode_name="AVOIDING OBSTACLE";
  st.motion.speed_l_mmps=-32768; st.motion.speed_r_mmps=-32768;
  st.motion.count_l=INT32_MIN; st.motion.count_r=INT32_MIN; st.motion.distance_mm=INT32_MIN;
  st.line.raw_l=-32768; st.line.raw_r=-32768; st.line.error_pm=-32768; st.line.letters=255; st.line.last_letter='Z';
  st.imu.humps=255; st.imu.max_height_mm=-32768; st.scan.obstacles=65535; st.scan.range_mm=-32768;
  st.imu.motion_class=IMU_CLASS_ACCELERATING; st.imu.turn_rate_dps=-32768;
  n=tlm_format_telemetry(&st,UINT32_MAX,UINT32_MAX,buf,sizeof buf); printf("telemetry %u\n%s\n",n,buf);
  st.nav.held_letter='Z'; st.nav.hold_reason=2; st.link.wifi_status=INT32_MIN; st.safety.b_faulted=1; st.safety.cause=6;
  st.safety.b_wdt_armed=1; st.safety.queue_full=255; st.safety.missed_checkins=65535; st.dropped=UINT32_MAX;
  n=tlm_format_heartbeat(&st,UINT32_MAX,UINT32_MAX,UINT32_MAX,buf,sizeof buf); printf("heartbeat %u\n%s\n",n,buf);
  tlm_route_t r={0}; r.kind=ROUTE_TURN; r.action=4; r.distance_mm=INT32_MIN; r.value=INT32_MIN; r.value2=INT32_MIN;
  n=tlm_format_route(&r,UINT32_MAX,UINT32_MAX,47,true,buf,sizeof buf); printf("route %u\n%s\n",n,buf);
  r.kind=ROUTE_SAFE_HOLD; r.value=3; n=tlm_format_route(&r,UINT32_MAX,UINT32_MAX,47,true,buf,sizeof buf); printf("route %u\n%s\n",n,buf);
  r.kind=ROUTE_OBSTACLE; r.action=2; r.value=INT32_MIN; n=tlm_format_route(&r,UINT32_MAX,UINT32_MAX,47,true,buf,sizeof buf); printf("route %u\n%s\n",n,buf);
  st.b_run_started=true; st.end_kind=ROUTE_NO_COMMAND; st.barcodes=65535; st.turns=65535; st.humps=65535; st.max_hump_mm=INT32_MIN; st.obstacles=65535; st.safety.faults=65535; st.log_count=48;
  st.run_start_ms=0; st.run_end_ms=UINT32_MAX; st.run_start_mm=0; st.run_end_mm=INT32_MIN;
  n=tlm_format_summary(&st,UINT32_MAX,UINT32_MAX,buf,sizeof buf); printf("summary %u\n%s\n",n,buf);
  tlm_ack_t a={UINT32_MAX,5,1,0,0}; n=tlm_format_ack(&a,UINT32_MAX,UINT32_MAX,buf,sizeof buf); printf("ack %u\n%s\n",n,buf);
  tlm_fault_t f={6,8,65535,1}; n=tlm_format_fault(&f,UINT32_MAX,UINT32_MAX,buf,sizeof buf); printf("fault %u\n%s\n",n,buf);
  n=tlm_format_motion_event(IMU_CLASS_ACCELERATING,INT32_MIN,UINT32_MAX,UINT32_MAX,buf,sizeof buf); printf("motion %u\n%s\n",n,buf);
  tlm_link_t l={1,INT32_MIN}; n=tlm_format_link(&l,UINT32_MAX,UINT32_MAX,buf,sizeof buf); printf("link %u\n%s\n",n,buf);
  return 0;}
